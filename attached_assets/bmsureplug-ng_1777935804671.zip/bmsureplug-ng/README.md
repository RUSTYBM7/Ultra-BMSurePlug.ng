# BMsureplug.ng — Social Media Growth Platform

A world-class, fully independent Next.js 14 website for BMsureplug.ng, rebuilt from the ground up with zero Replit dependencies and 100% Vercel deployment support.

## Brand Identity

- **Brand Name:** BMsureplug.ng (always written this way — never "bmsocial hub" in text)
- **Logo:** Embedded SVG vector logo with orange "hub" + play button icon
- **Primary Color:** `#FF6200` (Vibrant Orange)
- **Secondary:** `#111111` (Near Black)
- **Accent:** `#FFFFFF` (White)
- **Soft Accent:** `#F5D6D6` (Pale Pink)
- **Fonts:** Bebas Neue (headlines), Montserrat (body), Playfair Display (editorial)

## Features

- **3,700+ Services** across 20+ platforms (Instagram, TikTok, YouTube, Twitter/X, Facebook, Telegram, Spotify, LinkedIn, SoundCloud, Twitch, Pinterest, Threads, Snapchat, Google Reviews, WhatsApp)
- **6 Service Tiers:** Fast, Plus, Pro, Steady, Premium, Elite
- **Realistic Pricing:** All prices are Owlet base + 45%, with clean Naira values
- **Realistic Min/Max Orders:** No abnormal millions/hundreds-of-thousands for small services
- **Correct Platform Icons:** Every service shows the correct social media platform icon
- **No Web/Wrong Icons:** All services properly categorized by their actual platform
- **Fully Static Export:** `output: 'export'` — zero server dependencies
- **Vercel Ready:** Builds cleanly with `next build`, deploys instantly

## Pages

| Page | Path |
|------|------|
| Home | `/` |
| Services Catalog | `/services/` |
| Monthly Plans | `/plans/` |
| Dashboard | `/dashboard/` |
| Reseller Program | `/reseller/` |
| Marketplace | `/marketplace/` |
| Giveaway | `/giveaway/` |

## Local Development

```bash
npm install
npm run dev
```

## Build for Production

```bash
npm run build
```

Output goes to `dist/` folder as static HTML/CSS/JS — ready for any static host.

## Deploy to Vercel

### Option 1: CLI (after build)
```bash
npx vercel --prod
```

### Option 2: Using deploy.sh
```bash
chmod +x deploy.sh
./deploy.sh
```

### Option 3: Vercel Dashboard
1. Push code to GitHub
2. Import repo on [vercel.com](https://vercel.com)
3. Framework preset: Next.js
4. Build command: `npm run build`
5. Output directory: `dist`

## Project Structure

```
app/           → Next.js App Router pages
components/    → Reusable UI components
lib/           → Data & utilities
public/        → Static assets
```

## Tech Stack

- Next.js 14 (App Router, Static Export)
- React 18
- TypeScript
- Tailwind CSS
- Lucide React (icons)
- Framer Motion (animations)

---

**Built for BMsureplug.ng** — Nigeria&apos;s #1 Social Growth Studio.
