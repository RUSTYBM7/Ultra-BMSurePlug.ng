"use client";

import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Check, ArrowRight, TrendingUp, Users, Zap, Gift } from "lucide-react";

const tiers = [
  {
    name: "Bronze",
    discount: "Retail",
    unlock: "Default",
    features: [
      "Access to 3,700+ services",
      "Retail rate on all prices",
      "5% commission on referrals",
      "Email order notifications",
    ],
    popular: false,
  },
  {
    name: "Silver",
    discount: "-8%",
    unlock: "₦100,000 spent",
    features: [
      "8% discount on all services",
      "Priority order processing",
      "5% referral commission",
      "Monthly report",
    ],
    popular: false,
  },
  {
    name: "Gold",
    discount: "-15%",
    unlock: "₦500,000 spent",
    features: [
      "15% discount on all services",
      "API access for automation",
      "5% referral commission",
      "Account manager",
    ],
    popular: true,
  },
  {
    name: "Platinum",
    discount: "-22%",
    unlock: "₦2,000,000 spent",
    features: [
      "22% off — maximum savings",
      "Custom pricing on bulk",
      "5% referral commission",
      "White-label option",
    ],
    popular: false,
  },
];

const example = [
  { tier: "Bronze", retail: 1000, yourPrice: 1000, savings: 0 },
  { tier: "Silver", retail: 1000, yourPrice: 920, savings: 80 },
  { tier: "Gold", retail: 1000, yourPrice: 850, savings: 150 },
  { tier: "Platinum", retail: 1000, yourPrice: 780, savings: 220 },
];

export default function ResellerPage() {
  return (
    <>
      <Navbar />
      <div className="bg-[#FF6200] dot-bg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <h1 className="font-bebas text-5xl md:text-6xl text-white mb-3">RESELLER PROGRAM</h1>
          <p className="text-white/80 text-lg max-w-2xl mx-auto">
            Grow your income while growing others. Unlock wholesale pricing, earn 5% on every referral,
            and scale from Bronze to Platinum as your volume grows. No targets. No contracts.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Tier Cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-16">
          {tiers.map((t) => (
            <div
              key={t.name}
              className={`relative rounded-2xl p-6 border ${
                t.popular
                  ? "bg-[#111111] border-[#FF6200] text-white"
                  : "bg-white border-[#EEEEEE] text-[#111111]"
              }`}
            >
              {t.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[#FF6200] text-white text-xs font-bold px-3 py-1 rounded-full">
                  Most Popular
                </div>
              )}
              <h3 className="font-bebas text-2xl mb-1">{t.name}</h3>
              <div className={`font-bebas text-4xl mb-1 ${t.popular ? "text-[#FF6200]" : "text-[#FF6200]"}`}>
                {t.discount}
              </div>
              <p className={`text-xs mb-4 ${t.popular ? "text-white/50" : "text-[#AAAAAA]"}`}>
                Unlock at {t.unlock}
              </p>
              <ul className="space-y-2 mb-6">
                {t.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-sm">
                    <Check className={`w-4 h-4 shrink-0 mt-0.5 ${t.popular ? "text-[#FF6200]" : "text-[#FF6200]"}`} />
                    <span className={t.popular ? "text-white/80" : "text-[#111111]/80"}>{f}</span>
                  </li>
                ))}
              </ul>
              <button className={`w-full py-2.5 rounded font-bold text-sm transition-colors ${
                t.popular
                  ? "bg-[#FF6200] text-white hover:bg-[#e55800]"
                  : "bg-[#111111] text-white hover:bg-[#333333]"
              }`}>
                Join {t.name}
              </button>
            </div>
          ))}
        </div>

        {/* Pricing Example */}
        <div className="bg-[#FAFAFA] rounded-2xl p-8 mb-16">
          <h2 className="font-bebas text-3xl text-[#111111] mb-2">WHOLESALE PRICING EXAMPLE</h2>
          <p className="text-[#AAAAAA] text-sm mb-6">
            Based on IG Followers (Plus tier) at ₦725/1k
          </p>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#EEEEEE]">
                  <th className="text-left py-3 text-[#AAAAAA] font-medium">Tier</th>
                  <th className="text-right py-3 text-[#AAAAAA] font-medium">Retail /1k</th>
                  <th className="text-right py-3 text-[#AAAAAA] font-medium">Your Price /1k</th>
                  <th className="text-right py-3 text-[#AAAAAA] font-medium">Savings /1k</th>
                </tr>
              </thead>
              <tbody>
                {example.map((row) => (
                  <tr key={row.tier} className="border-b border-[#EEEEEE] last:border-0">
                    <td className="py-3 font-bold text-[#111111]">{row.tier}</td>
                    <td className="py-3 text-right text-[#111111]">₦{row.retail.toLocaleString()}</td>
                    <td className="py-3 text-right font-bold text-[#FF6200]">₦{row.yourPrice.toLocaleString()}</td>
                    <td className="py-3 text-right text-[#22c55e] font-medium">
                      {row.savings > 0 ? `₦${row.savings.toLocaleString()}` : "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {[
            { icon: TrendingUp, title: "Volume Scaling", desc: "The more you spend, the bigger your discount. Automatic tier upgrades." },
            { icon: Users, title: "Referral Earnings", desc: "Earn 5% on every order placed by users you refer. Forever." },
            { icon: Zap, title: "API Access", desc: "Gold+ tiers unlock programmatic ordering for full automation." },
            { icon: Gift, title: "White Label", desc: "Platinum resellers can brand reports and dashboards as their own." },
          ].map((f) => (
            <div key={f.title} className="bg-white border border-[#EEEEEE] rounded-xl p-5 text-center">
              <div className="w-10 h-10 bg-[#FF6200]/10 rounded-lg flex items-center justify-center mx-auto mb-3">
                <f.icon className="w-5 h-5 text-[#FF6200]" />
              </div>
              <h3 className="font-bold text-[#111111] text-sm mb-1">{f.title}</h3>
              <p className="text-[#AAAAAA] text-xs">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>

      <Footer />
    </>
  );
}
