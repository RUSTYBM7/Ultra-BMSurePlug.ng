"use client";

import Link from "next/link";
import { ArrowLeft } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen bg-[#0A0A0A] flex items-center justify-center px-4">
      <div className="text-center">
        <h1 className="font-bebas text-8xl text-[#FF6200] mb-2">404</h1>
        <h2 className="font-bebas text-3xl text-white mb-4">PAGE NOT FOUND</h2>
        <p className="text-white/50 text-sm mb-8 max-w-md mx-auto">
          The page you are looking for does not exist or has been moved.
        </p>
        <Link
          href="/"
          className="inline-flex items-center gap-2 px-6 py-3 bg-[#FF6200] text-white font-bold rounded hover:bg-[#e55800] transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Back to Home
        </Link>
      </div>
    </div>
  );
}
