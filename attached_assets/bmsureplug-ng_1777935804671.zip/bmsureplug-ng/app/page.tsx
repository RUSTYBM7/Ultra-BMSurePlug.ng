"use client";

import Link from "next/link";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import {
  Zap, Shield, RefreshCw, BarChart3, TrendingUp,
  Target, Link2, LineChart, Check, ArrowRight,
  Instagram, Youtube, Twitter, Facebook, Send,
  Headphones, Linkedin, Cloud, Radio, Pin,
  AtSign, Ghost, Star, MessageCircle, Music2,
  Play, Users, Eye, Heart, MessageSquare
} from "lucide-react";
import { platforms, totalServices } from "@/lib/services-data";

const stats = [
  { value: `${totalServices}+`, label: "Services Live" },
  { value: "20+", label: "Platforms" },
  { value: "10K+", label: "Happy Clients" },
  { value: "99.2%", label: "Uptime" },
];

const features = [
  { icon: Zap, title: "Instant Delivery", desc: "Orders start processing within minutes of placement, 24/7. Fast-tier services complete in under an hour." },
  { icon: Shield, title: "Zero Password Risk", desc: "We never ask for your login credentials. Your account stays private and secure." },
  { icon: RefreshCw, title: "Refill Guarantee", desc: "30-day drop protection on all refill-eligible services. We've got you covered." },
  { icon: BarChart3, title: "Real-Time Tracking", desc: "Watch your delivery live with progress counters updating in real time." },
  { icon: TrendingUp, title: "Reseller Discounts", desc: "Up to 22% wholesale pricing as your spending scales. Built for agencies." },
];

const steps = [
  { num: "01", icon: Target, title: "Choose a Service", desc: "Browse 3,700+ services across Instagram, TikTok, YouTube, Spotify, and 16 more platforms." },
  { num: "02", icon: Link2, title: "Paste Your Link", desc: "Drop your public profile or post URL. No login, no password, no account access needed." },
  { num: "03", icon: LineChart, title: "Track in Real Time", desc: "Watch your order go live instantly. Get notifications when it completes." },
];

const tierCards = [
  { name: "Fast", color: "#22c55e", desc: "Starts in minutes" },
  { name: "Plus", color: "#3b82f6", desc: "Best value" },
  { name: "Pro", color: "#f59e0b", desc: "Higher quality" },
  { name: "Steady", color: "#8b5cf6", desc: "Natural growth" },
  { name: "Premium", color: "#ec4899", desc: "Near-zero drop" },
  { name: "Elite", color: "#FF6200", desc: "Maximum quality" },
];

const platformIcons: Record<string, React.ElementType> = {
  Instagram, Youtube, Twitter, Facebook, Send,
  Headphones, Linkedin, Cloud, Radio, Pin,
  AtSign, Ghost, Star, MessageCircle, Music2,
};

export default function HomePage() {
  return (
    <>
      <Navbar />

      {/* Announcement Bar */}
      <div className="bg-[#FF6200] text-white text-center py-2 text-sm font-medium">
        🎉 {totalServices}+ services live on BMsureplug.ng &middot;{" "}
        <Link href="/services/" className="underline hover:no-underline">Browse catalog &rarr;</Link>
        {" "}&middot; Daily Giveaway 🎁
      </div>

      {/* Hero Section */}
      <section className="relative bg-[#FF6200] overflow-hidden">
        <div className="absolute inset-0 dot-bg opacity-30" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28">
          <div className="text-center max-w-4xl mx-auto">
            <div className="inline-flex items-center gap-2 bg-black/20 backdrop-blur-sm px-4 py-1.5 rounded-full text-white text-sm font-medium mb-6">
              <span className="text-lg">🇳🇬</span>
              Nigeria&apos;s #1 Social Growth Studio &middot; {totalServices}+ services live
            </div>
            <h1 className="font-bebas text-5xl md:text-7xl lg:text-8xl text-white leading-[0.95] mb-6">
              GROW YOUR BRAND<br />
              <span className="text-[#111111]">ON EVERY PLATFORM</span>
            </h1>
            <p className="text-white/90 text-lg md:text-xl max-w-2xl mx-auto mb-8 font-medium">
              BMsureplug.ng delivers real followers, views, and engagement across 20+ platforms.
              No passwords. Transparent Naira pricing. Built for Nigerian creators, trusted globally.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link
                href="/services/"
                className="inline-flex items-center px-8 py-3.5 bg-white text-[#111111] font-bold rounded hover:bg-white/90 transition-colors text-base"
              >
                Browse Services <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
              <Link
                href="/plans/"
                className="inline-flex items-center px-8 py-3.5 bg-transparent border-2 border-white text-white font-bold rounded hover:bg-white/10 transition-colors text-base"
              >
                View Plans
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-[#111111] py-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {stats.map((stat) => (
              <div key={stat.label}>
                <div className="font-bebas text-4xl md:text-5xl text-[#FF6200]">{stat.value}</div>
                <div className="text-white/60 text-sm mt-1 font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <h2 className="font-bebas text-4xl md:text-5xl text-[#111111] mb-3">WHY BMSUREPLUG.NG</h2>
            <p className="text-[#AAAAAA] text-lg">Everything you need to dominate social media.</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((f) => (
              <div key={f.title} className="bg-[#FAFAFA] border border-[#EEEEEE] rounded-xl p-6 hover:border-[#FF6200]/30 transition-colors group">
                <div className="w-12 h-12 bg-[#FF6200]/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-[#FF6200]/20 transition-colors">
                  <f.icon className="w-6 h-6 text-[#FF6200]" />
                </div>
                <h3 className="font-bold text-[#111111] text-lg mb-2">{f.title}</h3>
                <p className="text-[#AAAAAA] text-sm leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-[#FAFAFA]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <h2 className="font-bebas text-4xl md:text-5xl text-[#111111] mb-3">HOW IT WORKS</h2>
            <p className="text-[#AAAAAA] text-lg">Three steps. Zero friction.</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {steps.map((step) => (
              <div key={step.num} className="text-center">
                <div className="w-16 h-16 bg-[#FF6200] rounded-2xl flex items-center justify-center mx-auto mb-5 rotate-3">
                  <step.icon className="w-8 h-8 text-white" />
                </div>
                <div className="font-bebas text-3xl text-[#FF6200] mb-2">{step.num}</div>
                <h3 className="font-bold text-[#111111] text-lg mb-2">{step.title}</h3>
                <p className="text-[#AAAAAA] text-sm max-w-xs mx-auto">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Service Tiers */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <h2 className="font-bebas text-4xl md:text-5xl text-[#111111] mb-3">SERVICE TIERS</h2>
            <p className="text-[#AAAAAA] text-lg">Six tiers. Every budget. Every goal.</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {tierCards.map((tier) => (
              <div
                key={tier.name}
                className="bg-[#FAFAFA] border border-[#EEEEEE] rounded-xl p-5 text-center hover:shadow-lg transition-shadow"
              >
                <div className="w-3 h-3 rounded-full mx-auto mb-3" style={{ backgroundColor: tier.color }} />
                <h3 className="font-bebas text-2xl text-[#111111]">{tier.name}</h3>
                <p className="text-[#AAAAAA] text-xs mt-1">{tier.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Platforms Grid */}
      <section className="py-20 bg-[#111111]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <h2 className="font-bebas text-4xl md:text-5xl text-white mb-3">PLATFORMS WE SUPPORT</h2>
            <p className="text-white/50 text-lg">20+ platforms. One dashboard.</p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {platforms.map((p) => {
              const IconComp = platformIcons[p.icon] || Star;
              return (
                <Link
                  key={p.name}
                  href={`/services/`}
                  className="bg-white/5 border border-white/10 rounded-xl p-5 text-center hover:bg-white/10 hover:border-[#FF6200]/40 transition-all group"
                >
                  <IconComp className="w-8 h-8 mx-auto mb-3 text-white/60 group-hover:text-[#FF6200] transition-colors" />
                  <span className="text-white text-sm font-medium">{p.name}</span>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* Offer Banner */}
      <section className="py-16 bg-[#FF6200]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-8">
            <div>
              <h2 className="font-bebas text-4xl md:text-5xl text-white mb-2">NEW USERS ENJOY</h2>
              <p className="text-white/80 text-lg">Kickstart your growth with free credits.</p>
            </div>
            <div className="bg-[#F5D6D6] rounded-2xl p-6 max-w-md w-full">
              <div className="inline-block bg-[#111111] text-white text-xs font-bold px-3 py-1 rounded-full mb-4">
                New users enjoy:
              </div>
              <ul className="space-y-3">
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-[#FF6200] shrink-0 mt-0.5" />
                  <span className="text-[#111111] text-sm font-medium">Get 200K FREE TikTok views</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-[#FF6200] shrink-0 mt-0.5" />
                  <span className="text-[#111111] text-sm font-medium">Get FREE IG views, likes & post boost</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Reseller Teaser */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <h2 className="font-bebas text-4xl md:text-5xl text-[#111111] mb-3">RESELLER PROGRAM</h2>
            <p className="text-[#AAAAAA] text-lg">Built for agencies. Earn while you grow.</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 max-w-4xl mx-auto">
            {[
              { name: "Bronze", discount: "Retail", unlock: "Default", popular: false },
              { name: "Silver", discount: "-8%", unlock: "₦100K spent", popular: false },
              { name: "Gold", discount: "-15%", unlock: "₦500K spent", popular: true },
              { name: "Platinum", discount: "-22%", unlock: "₦2M spent", popular: false },
            ].map((tier) => (
              <div
                key={tier.name}
                className={`relative rounded-xl p-6 text-center border ${
                  tier.popular
                    ? "bg-[#111111] border-[#FF6200] text-white"
                    : "bg-[#FAFAFA] border-[#EEEEEE] text-[#111111]"
                }`}
              >
                {tier.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[#FF6200] text-white text-xs font-bold px-3 py-1 rounded-full">
                    Most Popular
                  </div>
                )}
                <h3 className="font-bebas text-2xl mb-1">{tier.name}</h3>
                <div className={`text-2xl font-bold mb-1 ${tier.popular ? "text-[#FF6200]" : "text-[#FF6200]"}`}>
                  {tier.discount}
                </div>
                <p className={`text-xs ${tier.popular ? "text-white/60" : "text-[#AAAAAA]"}`}>
                  Unlock at {tier.unlock}
                </p>
              </div>
            ))}
          </div>
          <div className="text-center mt-8">
            <Link
              href="/reseller/"
              className="inline-flex items-center px-6 py-3 bg-[#FF6200] text-white font-bold rounded hover:bg-[#e55800] transition-colors"
            >
              Join Reseller Program <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-[#0A0A0A]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-bebas text-4xl md:text-6xl text-white mb-4">
            YOUR NEXT 10,000 FOLLOWERS ARE 3 CLICKS AWAY
          </h2>
          <p className="text-white/60 text-lg mb-8 max-w-2xl mx-auto">
            Join 10,000+ creators and agencies already growing with BMsureplug.ng.
            No passwords. No risk. Pure results.
          </p>
          <Link
            href="/services/"
            className="inline-flex items-center px-8 py-4 bg-[#FF6200] text-white font-bold rounded hover:bg-[#e55800] transition-colors text-lg"
          >
            Get Started Now <ArrowRight className="ml-2 w-5 h-5" />
          </Link>
        </div>
      </section>

      <Footer />
    </>
  );
}
