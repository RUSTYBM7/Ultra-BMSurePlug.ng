"use client";

import { useState, useMemo } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import {
  Search, Filter, Instagram, Youtube, Twitter, Facebook, Send,
  Headphones, Linkedin, Cloud, Radio, Pin, AtSign, Ghost, Star,
  MessageCircle, Music2, Check, Clock, Shield, ChevronDown,
  ArrowRight
} from "lucide-react";
import { platforms, tiers, tierInfo, type Tier, type Service } from "@/lib/services-data";

const platformIcons: Record<string, React.ElementType> = {
  Instagram, Youtube, Twitter, Facebook, Send,
  Headphones, Linkedin, Cloud, Radio, Pin,
  AtSign, Ghost, Star, MessageCircle, Music2,
};

function ServiceCard({ service }: { service: Service }) {
  const [qty, setQty] = useState(service.minOrder);
  const tier = tierInfo[service.tier];
  const total = Math.round((qty / 1000) * service.pricePer1k);

  return (
    <div className="bg-white border border-[#EEEEEE] rounded-xl p-5 hover:border-[#FF6200]/40 hover:shadow-lg transition-all group">
      <div className="flex items-start justify-between mb-3">
        <div>
          <span
            className="inline-block text-xs font-bold px-2 py-0.5 rounded text-white mb-2"
            style={{ backgroundColor: tier.color }}
          >
            {service.tier}
          </span>
          <h3 className="font-bold text-[#111111] text-base">{service.serviceType}</h3>
          <p className="text-[#AAAAAA] text-xs mt-0.5">{service.description}</p>
        </div>
        <div className="text-right">
          <div className="font-bebas text-2xl text-[#FF6200]">₦{service.pricePer1k.toLocaleString()}</div>
          <div className="text-[#AAAAAA] text-xs">per 1,000</div>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mb-4">
        {service.features.map((f) => (
          <span key={f} className="inline-flex items-center gap-1 text-xs text-[#111111]/70 bg-[#FAFAFA] px-2 py-1 rounded">
            <Check className="w-3 h-3 text-[#FF6200]" /> {f}
          </span>
        ))}
      </div>

      <div className="flex items-center gap-4 text-xs text-[#AAAAAA] mb-4">
        <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {service.deliveryTime}</span>
        {service.refillGuarantee && (
          <span className="flex items-center gap-1"><Shield className="w-3 h-3" /> Refill guaranteed</span>
        )}
      </div>

      <div className="flex items-center gap-3">
        <div className="flex-1">
          <label className="text-xs text-[#AAAAAA] mb-1 block">Quantity</label>
          <input
            type="number"
            min={service.minOrder}
            max={service.maxOrder}
            value={qty}
            onChange={(e) => setQty(Math.max(service.minOrder, Math.min(service.maxOrder, parseInt(e.target.value) || service.minOrder)))}
            className="w-full px-3 py-2 border border-[#EEEEEE] rounded text-sm focus:outline-none focus:border-[#FF6200]"
          />
          <div className="text-[10px] text-[#AAAAAA] mt-1">
            Min: {service.minOrder.toLocaleString()} &middot; Max: {service.maxOrder.toLocaleString()}
          </div>
        </div>
        <div className="text-right">
          <div className="text-xs text-[#AAAAAA] mb-1">Total</div>
          <div className="font-bebas text-2xl text-[#111111]">₦{total.toLocaleString()}</div>
        </div>
      </div>

      <button className="w-full mt-4 py-2.5 bg-[#FF6200] text-white font-bold text-sm rounded hover:bg-[#e55800] transition-colors flex items-center justify-center gap-2">
        Order Now <ArrowRight className="w-4 h-4" />
      </button>
    </div>
  );
}

export default function ServicesPage() {
  const [search, setSearch] = useState("");
  const [selectedPlatform, setSelectedPlatform] = useState<string>("All");
  const [selectedTier, setSelectedTier] = useState<Tier | "All">("All");
  const [showFilters, setShowFilters] = useState(false);

  const filtered = useMemo(() => {
    let services = platforms.flatMap((p) => p.services);
    if (selectedPlatform !== "All") {
      services = services.filter((s) => s.platform === selectedPlatform);
    }
    if (selectedTier !== "All") {
      services = services.filter((s) => s.tier === selectedTier);
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      services = services.filter(
        (s) =>
          s.serviceType.toLowerCase().includes(q) ||
          s.platform.toLowerCase().includes(q) ||
          s.description.toLowerCase().includes(q)
      );
    }
    return services;
  }, [search, selectedPlatform, selectedTier]);

  return (
    <>
      <Navbar />
      <div className="bg-[#FF6200] dot-bg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <h1 className="font-bebas text-5xl md:text-6xl text-white mb-3">SERVICE CATALOG</h1>
          <p className="text-white/80 text-lg">
            {platforms.reduce((acc, p) => acc + p.services.length, 0)}+ services. Every platform.
          </p>
          <p className="text-white/60 text-sm mt-1">
            Structured across six tiers — Fast, Plus, Pro, Steady, Premium, Elite.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search & Filter Bar */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#AAAAAA]" />
            <input
              type="text"
              placeholder="Search services, platforms, or types..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-[#EEEEEE] rounded-xl text-sm focus:outline-none focus:border-[#FF6200] bg-white"
            />
          </div>
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="inline-flex items-center gap-2 px-5 py-3 border border-[#EEEEEE] rounded-xl text-sm font-medium hover:border-[#FF6200] transition-colors bg-white"
          >
            <Filter className="w-4 h-4" /> Filters <ChevronDown className={`w-4 h-4 transition-transform ${showFilters ? "rotate-180" : ""}`} />
          </button>
        </div>

        {showFilters && (
          <div className="bg-[#FAFAFA] border border-[#EEEEEE] rounded-xl p-5 mb-6">
            <div className="mb-4">
              <label className="text-xs font-bold text-[#111111] uppercase mb-2 block">Platform</label>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => setSelectedPlatform("All")}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
                    selectedPlatform === "All" ? "bg-[#FF6200] text-white" : "bg-white border border-[#EEEEEE] text-[#111111] hover:border-[#FF6200]"
                  }`}
                >
                  All Platforms
                </button>
                {platforms.map((p) => {
                  const Icon = platformIcons[p.icon] || Star;
                  return (
                    <button
                      key={p.name}
                      onClick={() => setSelectedPlatform(p.name)}
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
                        selectedPlatform === p.name ? "bg-[#FF6200] text-white" : "bg-white border border-[#EEEEEE] text-[#111111] hover:border-[#FF6200]"
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" /> {p.name}
                    </button>
                  );
                })}
              </div>
            </div>
            <div>
              <label className="text-xs font-bold text-[#111111] uppercase mb-2 block">Tier</label>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => setSelectedTier("All")}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
                    selectedTier === "All" ? "bg-[#FF6200] text-white" : "bg-white border border-[#EEEEEE] text-[#111111] hover:border-[#FF6200]"
                  }`}
                >
                  All Tiers
                </button>
                {tiers.map((t) => (
                  <button
                    key={t}
                    onClick={() => setSelectedTier(t)}
                    className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
                      selectedTier === t ? "bg-[#FF6200] text-white" : "bg-white border border-[#EEEEEE] text-[#111111] hover:border-[#FF6200]"
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Results count */}
        <div className="flex items-center justify-between mb-4">
          <p className="text-sm text-[#AAAAAA]">
            Showing <span className="font-bold text-[#111111]">{filtered.length}</span> services
          </p>
        </div>

        {/* Services Grid */}
        {filtered.length > 0 ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {filtered.map((service) => (
              <ServiceCard key={service.id} service={service} />
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <Search className="w-12 h-12 text-[#AAAAAA] mx-auto mb-4" />
            <h3 className="font-bold text-[#111111] text-lg mb-2">No services found</h3>
            <p className="text-[#AAAAAA] text-sm">Try adjusting your search or filters.</p>
          </div>
        )}
      </div>

      <Footer />
    </>
  );
}
