"use client";

import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Check, ArrowRight, Zap } from "lucide-react";
import Link from "next/link";

const plans = [
  {
    name: "Starter",
    price: 49000,
    period: "per month",
    tag: null,
    features: [
      "5,000 Instagram Followers/mo",
      "10,000 TikTok Views/mo",
      "2,000 YouTube Views/mo",
      "2 platforms covered",
      "Monthly performance report",
      "Email support (48hr response)",
      "Refill guarantee",
    ],
    desc: "Ideal for solo creators, influencers starting out, and small Nigerian brands.",
  },
  {
    name: "Growth",
    price: 149000,
    period: "per month",
    tag: "Most Popular",
    features: [
      "20,000 Instagram Followers/mo",
      "50,000 TikTok Views + Likes",
      "10,000 YouTube Subscribers/mo",
      "5,000 Telegram Members/mo",
      "4 platforms covered",
      "Bi-weekly analytics report",
      "Priority email support (12hr)",
      "30-day refill protection",
      "Dedicated growth strategy",
    ],
    desc: "Perfect for SMEs, e-commerce brands, and growing Nigerian businesses.",
  },
  {
    name: "Enterprise",
    price: 399000,
    period: "per month",
    tag: "Agency Grade",
    features: [
      "Unlimited monthly engagement",
      "10+ platforms covered",
      "Dedicated account manager",
      "Custom growth strategy",
      "24/7 WhatsApp priority support",
      "Weekly analytics & reporting",
      "API access for bulk orders",
      "White-label reporting available",
      "SLA-backed delivery",
    ],
    desc: "Built for agencies, media houses, and enterprises managing multiple brands.",
  },
];

export default function PlansPage() {
  return (
    <>
      <Navbar />
      <div className="bg-[#FF6200] dot-bg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <h1 className="font-bebas text-5xl md:text-6xl text-white mb-3">PREDICTABLE GROWTH</h1>
          <p className="text-white/80 text-lg max-w-2xl mx-auto">
            Monthly packages built for Nigerian businesses that are serious about scaling their social presence.
            No guesswork. No waste. Just growth.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`relative rounded-2xl p-7 border ${
                plan.tag === "Most Popular"
                  ? "bg-[#111111] border-[#FF6200] text-white"
                  : "bg-white border-[#EEEEEE] text-[#111111]"
              }`}
            >
              {plan.tag && (
                <div className={`absolute -top-3 left-1/2 -translate-x-1/2 text-xs font-bold px-3 py-1 rounded-full ${
                  plan.tag === "Most Popular" ? "bg-[#FF6200] text-white" : "bg-[#111111] text-white"
                }`}>
                  {plan.tag}
                </div>
              )}
              <h3 className="font-bebas text-2xl mb-1">{plan.name}</h3>
              <div className="flex items-baseline gap-1 mb-1">
                <span className={`font-bebas text-4xl ${plan.tag === "Most Popular" ? "text-[#FF6200]" : "text-[#FF6200]"}`}>
                  ₦{plan.price.toLocaleString()}
                </span>
              </div>
              <p className={`text-xs mb-5 ${plan.tag === "Most Popular" ? "text-white/50" : "text-[#AAAAAA]"}`}>
                {plan.period} &middot; billed monthly
              </p>
              <ul className="space-y-2.5 mb-6">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-sm">
                    <Check className={`w-4 h-4 shrink-0 mt-0.5 ${plan.tag === "Most Popular" ? "text-[#FF6200]" : "text-[#FF6200]"}`} />
                    <span className={plan.tag === "Most Popular" ? "text-white/80" : "text-[#111111]/80"}>{f}</span>
                  </li>
                ))}
              </ul>
              <p className={`text-xs mb-5 ${plan.tag === "Most Popular" ? "text-white/40" : "text-[#AAAAAA]"}`}>
                {plan.desc}
              </p>
              <button className={`w-full py-2.5 rounded font-bold text-sm flex items-center justify-center gap-2 transition-colors ${
                plan.tag === "Most Popular"
                  ? "bg-[#FF6200] text-white hover:bg-[#e55800]"
                  : "bg-[#111111] text-white hover:bg-[#333333]"
              }`}>
                Choose {plan.name} <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>

        {/* Custom CTA */}
        <div className="text-center mt-12 bg-[#FAFAFA] rounded-2xl p-8 max-w-2xl mx-auto">
          <h3 className="font-bebas text-2xl text-[#111111] mb-2">NEED SOMETHING CUSTOM?</h3>
          <p className="text-[#AAAAAA] text-sm mb-4">
            All plans are fully customisable. Mix and match platforms, volumes, and delivery speeds.
          </p>
          <Link
            href="/services/"
            className="inline-flex items-center gap-2 px-6 py-2.5 bg-[#FF6200] text-white font-bold text-sm rounded hover:bg-[#e55800] transition-colors"
          >
            <Zap className="w-4 h-4" /> Build Custom Plan
          </Link>
        </div>

        <p className="text-center text-[#AAAAAA] text-xs mt-8">
          All plans are recurring monthly subscriptions. Cancel anytime. Prices in Nigerian Naira (NGN).
          Powered by Paystack secure checkout.
        </p>
      </div>

      <Footer />
    </>
  );
}
