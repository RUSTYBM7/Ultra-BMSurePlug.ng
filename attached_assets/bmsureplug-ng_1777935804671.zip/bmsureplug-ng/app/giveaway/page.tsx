"use client";

import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Gift, Ticket, Users, ShoppingBag, Trophy, Clock } from "lucide-react";

const prizes = [
  { name: "₦5,000 Credit", desc: "Free service credits", icon: Gift },
  { name: "₦10,000 Bundle", desc: "Premium service pack", icon: Trophy },
  { name: "1,000 Free Followers", desc: "IG or TikTok", icon: Users },
  { name: "Free Growth Plan", desc: "7-day access", icon: ShoppingBag },
];

const ways = [
  { icon: Ticket, title: "Join the daily draw", desc: "One free entry every day — just sign in and click enter." },
  { icon: Users, title: "Per referral", desc: "Each person you refer gives you one extra ticket in every draw." },
  { icon: ShoppingBag, title: "Per order placed", desc: "Every order you place earns you 3 points toward the weekly challenge." },
];

export default function GiveawayPage() {
  return (
    <>
      <Navbar />
      <div className="bg-[#FF6200] dot-bg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <h1 className="font-bebas text-5xl md:text-6xl text-white mb-3">DAILY GIVEAWAY + WEEKLY CHALLENGE</h1>
          <p className="text-white/80 text-lg max-w-2xl mx-auto">
            Win every day. Compete every week. Enter the daily draw for free service credits.
            Refer friends for extra entries. Top weekly performers win massive prize bundles.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Sign In CTA */}
        <div className="bg-[#111111] rounded-2xl p-8 text-center mb-12">
          <h2 className="font-bebas text-3xl text-white mb-2">SIGN IN TO TRACK YOUR RANK</h2>
          <p className="text-white/50 text-sm mb-5">Be the first winner today!</p>
          <button className="px-8 py-3 bg-[#FF6200] text-white font-bold rounded hover:bg-[#e55800] transition-colors">
            Sign In to Enter
          </button>
        </div>

        {/* Ways to Enter */}
        <div className="grid md:grid-cols-3 gap-6 mb-16">
          {ways.map((w) => (
            <div key={w.title} className="bg-white border border-[#EEEEEE] rounded-xl p-6 text-center">
              <div className="w-12 h-12 bg-[#FF6200]/10 rounded-xl flex items-center justify-center mx-auto mb-4">
                <w.icon className="w-6 h-6 text-[#FF6200]" />
              </div>
              <h3 className="font-bold text-[#111111] mb-2">{w.title}</h3>
              <p className="text-[#AAAAAA] text-sm">{w.desc}</p>
            </div>
          ))}
        </div>

        {/* Prizes */}
        <div className="text-center mb-8">
          <h2 className="font-bebas text-3xl text-[#111111] mb-2">WHAT YOU CAN WIN</h2>
          <p className="text-[#AAAAAA] text-sm">Winners are randomly selected at midnight (WAT). Weekly prizes distributed every Sunday.</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-12">
          {prizes.map((p) => (
            <div key={p.name} className="bg-[#FAFAFA] border border-[#EEEEEE] rounded-xl p-6 text-center">
              <div className="w-10 h-10 bg-[#FF6200]/10 rounded-lg flex items-center justify-center mx-auto mb-3">
                <p.icon className="w-5 h-5 text-[#FF6200]" />
              </div>
              <h3 className="font-bold text-[#111111] text-sm mb-1">{p.name}</h3>
              <p className="text-[#AAAAAA] text-xs">{p.desc}</p>
            </div>
          ))}
        </div>

        {/* Rules */}
        <div className="bg-[#FAFAFA] rounded-xl p-6 max-w-2xl mx-auto">
          <div className="flex items-center gap-2 mb-3">
            <Clock className="w-5 h-5 text-[#FF6200]" />
            <h3 className="font-bold text-[#111111] text-sm">Rules & Timing</h3>
          </div>
          <ul className="space-y-2 text-sm text-[#AAAAAA]">
            <li>• Winners are randomly selected at midnight (WAT).</li>
            <li>• Weekly prizes distributed every Sunday.</li>
            <li>• Must have an active account to claim.</li>
            <li>• Referral entries are unlimited — invite as many as you want.</li>
          </ul>
        </div>
      </div>

      <Footer />
    </>
  );
}
