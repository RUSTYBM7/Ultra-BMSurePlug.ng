"use client";

import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import {
  BarChart3, TrendingUp, Eye, Users, ShoppingCart,
  RefreshCw, Clock, AlertCircle, ArrowRight
} from "lucide-react";

const stats = [
  { label: "Total Orders", value: "0", icon: ShoppingCart, color: "#FF6200" },
  { label: "Active Orders", value: "0", icon: Clock, color: "#3b82f6" },
  { label: "Completed", value: "0", icon: TrendingUp, color: "#22c55e" },
  { label: "Total Spent", value: "₦0", icon: BarChart3, color: "#8b5cf6" },
];

const platforms = [
  { name: "Instagram", orders: 0, status: "Active" },
  { name: "TikTok", orders: 0, status: "Active" },
  { name: "YouTube", orders: 0, status: "Active" },
  { name: "Twitter / X", orders: 0, status: "Active" },
  { name: "Facebook", orders: 0, status: "Active" },
  { name: "Telegram", orders: 0, status: "Active" },
];

const topServices = [
  { name: "Instagram Followers (Plus)", orders: 0, trend: "up" },
  { name: "TikTok Views (Fast)", orders: 0, trend: "up" },
  { name: "YouTube Subscribers (Pro)", orders: 0, trend: "neutral" },
  { name: "Twitter Followers (Plus)", orders: 0, trend: "up" },
  { name: "Telegram Members (Fast)", orders: 0, trend: "neutral" },
];

export default function DashboardPage() {
  return (
    <>
      <Navbar />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="font-bebas text-4xl text-[#111111] mb-2">LIVE DASHBOARD</h1>
        <p className="text-[#AAAAAA] text-sm mb-8">Platform Overview</p>

        {/* Stats */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {stats.map((s) => (
            <div key={s.label} className="bg-white border border-[#EEEEEE] rounded-xl p-5">
              <div className="flex items-center justify-between mb-3">
                <span className="text-[#AAAAAA] text-xs font-medium">{s.label}</span>
                <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: s.color + "15" }}>
                  <s.icon className="w-4 h-4" style={{ color: s.color }} />
                </div>
              </div>
              <div className="font-bebas text-3xl text-[#111111]">{s.value}</div>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Platforms */}
          <div className="lg:col-span-2 bg-white border border-[#EEEEEE] rounded-xl p-6">
            <h2 className="font-bold text-[#111111] mb-4 flex items-center gap-2">
              <Eye className="w-5 h-5 text-[#FF6200]" /> Platforms
            </h2>
            <div className="space-y-3">
              {platforms.map((p) => (
                <div key={p.name} className="flex items-center justify-between py-2 border-b border-[#FAFAFA] last:border-0">
                  <span className="text-sm text-[#111111]">{p.name}</span>
                  <div className="flex items-center gap-4">
                    <span className="text-xs text-[#AAAAAA]">{p.orders} orders</span>
                    <span className="text-xs font-medium text-[#22c55e] bg-[#22c55e]/10 px-2 py-0.5 rounded">{p.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Top Services */}
          <div className="bg-white border border-[#EEEEEE] rounded-xl p-6">
            <h2 className="font-bold text-[#111111] mb-4 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-[#FF6200]" /> Top Services
            </h2>
            <div className="space-y-3">
              {topServices.map((s) => (
                <div key={s.name} className="flex items-center justify-between py-2 border-b border-[#FAFAFA] last:border-0">
                  <span className="text-sm text-[#111111] truncate max-w-[180px]">{s.name}</span>
                  <span className="text-xs text-[#AAAAAA]">{s.orders}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* API Section */}
        <div className="mt-8 bg-[#111111] rounded-xl p-6">
          <h2 className="font-bebas text-2xl text-white mb-2">RESELLER API ACCESS</h2>
          <p className="text-white/50 text-sm mb-4">Programmatic access to the full BMsureplug catalog</p>
          <div className="bg-[#0A0A0A] rounded-lg p-4 font-mono text-xs text-[#FF6200] space-y-1 overflow-x-auto">
            <p><span className="text-white/40">GET</span> /api/services?platform=instagram&tier=Plus</p>
            <p><span className="text-white/40">POST</span> /api/orders</p>
            <p><span className="text-white/40">GET</span> /api/orders/&#123;id&#125;</p>
            <p><span className="text-white/40">POST</span> /api/orders/&#123;id&#125;/refill</p>
          </div>
          <p className="text-white/40 text-xs mt-3">
            API access unlocks after minimum spend. Volume discounts apply progressively.
          </p>
        </div>
      </div>
      <Footer />
    </>
  );
}
