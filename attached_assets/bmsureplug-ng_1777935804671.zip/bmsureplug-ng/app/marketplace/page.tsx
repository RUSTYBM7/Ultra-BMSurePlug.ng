"use client";

import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Shield, UserCheck, Tag, Mail, ArrowRight } from "lucide-react";

export default function MarketplacePage() {
  return (
    <>
      <Navbar />
      <div className="bg-[#111111] min-h-[60vh] flex items-center">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
          <h1 className="font-bebas text-5xl md:text-7xl text-white mb-4">
            BM MARKETPLACE
          </h1>
          <p className="text-white/60 text-lg mb-2">
            Buy & sell social media accounts. Safe. Verified. Nigerian-built.
          </p>
          <p className="text-white/40 text-sm mb-10 max-w-xl mx-auto">
            The largest verified social media account marketplace in Nigeria.
            Every account manually checked, every transaction secured by Paystack.
          </p>

          <div className="inline-flex items-center gap-3 bg-[#FF6200]/20 border border-[#FF6200]/30 rounded-full px-6 py-3 mb-12">
            <span className="w-2 h-2 bg-[#FF6200] rounded-full animate-pulse" />
            <span className="text-[#FF6200] font-bold text-sm">Opening soon — Join the waitlist</span>
          </div>

          <div className="grid sm:grid-cols-3 gap-5 max-w-3xl mx-auto mb-12">
            {[
              { icon: Shield, title: "Buyer Protection", desc: "Every transaction is Paystack-secured. If the account isn't as described, you're fully refunded." },
              { icon: UserCheck, title: "Verified Sellers Only", desc: "All sellers pass a manual identity + account verification process before listing." },
              { icon: Tag, title: "Best Prices in Nigeria", desc: "Market-rate pricing with transparent negotiation. No hidden fees or inflated rates." },
            ].map((item) => (
              <div key={item.title} className="bg-white/5 border border-white/10 rounded-xl p-5 text-left">
                <item.icon className="w-6 h-6 text-[#FF6200] mb-3" />
                <h3 className="text-white font-bold text-sm mb-1">{item.title}</h3>
                <p className="text-white/40 text-xs leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>

          <div className="bg-[#FF6200] rounded-2xl p-8 max-w-lg mx-auto">
            <h3 className="font-bebas text-3xl text-white mb-2">COMING SOON</h3>
            <p className="text-white/80 text-sm mb-5">
              The BM Marketplace is being built — a verified, secure account trading platform built for Nigerians.
            </p>
            <div className="flex gap-3">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-4 py-2.5 rounded bg-white/20 text-white placeholder-white/50 text-sm focus:outline-none focus:bg-white/30"
              />
              <button className="px-5 py-2.5 bg-white text-[#FF6200] font-bold text-sm rounded hover:bg-white/90 transition-colors flex items-center gap-1">
                <Mail className="w-4 h-4" /> Join
              </button>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}
