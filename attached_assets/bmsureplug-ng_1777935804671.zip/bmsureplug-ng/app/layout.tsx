import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "BMsureplug.ng — Nigeria's #1 Social Growth Platform",
  description: "BMsureplug.ng delivers real followers, views, and engagement across 20+ platforms. No passwords. Transparent Naira pricing. Built for Nigerian creators, trusted globally.",
  keywords: "social media growth, Instagram followers Nigeria, TikTok views, YouTube subscribers, buy followers Nigeria, BMsureplug",
  openGraph: {
    title: "BMsureplug.ng — Nigeria's #1 Social Growth Platform",
    description: "3,700+ services live. Real results, fast. No passwords. Transparent Naira pricing.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-white">
        {children}
      </body>
    </html>
  );
}
