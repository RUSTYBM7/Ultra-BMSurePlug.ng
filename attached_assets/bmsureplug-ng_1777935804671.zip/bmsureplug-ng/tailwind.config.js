/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          orange: '#FF6200',
          black: '#111111',
          white: '#FFFFFF',
          pink: '#F5D6D6',
          dark: '#0A0A0A',
          muted: '#AAAAAA',
        }
      },
      fontFamily: {
        bebas: ['Bebas Neue', 'sans-serif'],
        montserrat: ['Montserrat', 'sans-serif'],
        playfair: ['Playfair Display', 'serif'],
      },
      backgroundImage: {
        'dot-pattern': "radial-gradient(circle, rgba(255,255,255,0.12) 1px, transparent 1px)",
      }
    },
  },
  plugins: [],
}
