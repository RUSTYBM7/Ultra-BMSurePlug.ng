#!/bin/bash
set -e

echo "📦 BMsureplug.ng Vercel Deploy Script"
echo "========================================"

# Check for zip
ZIP=$(ls *.zip 2>/dev/null | head -n1)
if [ -z "$ZIP" ]; then
    echo "❌ No ZIP file found in current directory"
    echo "   Please upload your project ZIP first"
    exit 1
fi

echo "📦 Using: $ZIP"

TMP=$(mktemp -d)
echo "📁 Temp dir: $TMP"

unzip -q "$ZIP" -d "$TMP"
cd "$TMP"

# Enter inner folder if single root dir
DIRS=$(find . -maxdepth 1 -type d | wc -l)
if [ "$DIRS" -eq 2 ]; then
    cd */
    echo "📂 Entered inner folder: $(pwd)"
fi

echo "🔧 Installing dependencies..."
npm install

echo "🏗️  Building for production..."
npm run build

echo "🚀 Deploying to Vercel..."
npx --yes vercel deploy --prod --yes

echo "🧹 Cleaning up..."
cd ~
rm -rf "$TMP"

echo ""
echo "✅ Done! Your BMsureplug.ng site is live on Vercel."
echo "   No files left behind."
