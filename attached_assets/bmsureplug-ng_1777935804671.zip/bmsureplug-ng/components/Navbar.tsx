"use client";

import { useState } from "react";
import Link from "next/link";
import { Menu, X, Play } from "lucide-react";

const navLinks = [
  { href: "/services/", label: "Services" },
  { href: "/plans/", label: "Plans" },
  { href: "/marketplace/", label: "Marketplace" },
  { href: "/dashboard/", label: "Dashboard" },
  { href: "/reseller/", label: "Reseller" },
  { href: "/giveaway/", label: "Giveaway 🎁" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 bg-[#111111] border-b border-[#FF6200]/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-1 group">
            <span className="text-white font-bold text-lg tracking-tight" style={{ fontFamily: "'Montserrat', sans-serif" }}>
              bmsocial
            </span>
            <span className="relative flex items-center">
              <span className="text-[#FF6200] font-bebas text-2xl leading-none">hub</span>
              <span className="absolute -right-3 top-1/2 -translate-y-1/2 w-3 h-3 bg-[#FF6200] rounded-full flex items-center justify-center">
                <Play className="w-1.5 h-1.5 text-white fill-white" />
              </span>
            </span>
          </Link>

          {/* Desktop Links */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="text-sm text-white/80 hover:text-[#FF6200] transition-colors duration-200 font-medium"
              >
                {link.label}
              </Link>
            ))}
          </div>

          {/* CTA */}
          <div className="hidden md:block">
            <Link
              href="/services/"
              className="inline-flex items-center px-5 py-2 bg-[#FF6200] text-white text-sm font-semibold rounded hover:bg-[#e55800] transition-colors"
            >
              Get Started
            </Link>
          </div>

          {/* Mobile toggle */}
          <button
            onClick={() => setOpen(!open)}
            className="md:hidden text-white p-2"
          >
            {open ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden bg-[#111111] border-t border-white/10">
          <div className="px-4 py-4 space-y-3">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setOpen(false)}
                className="block text-white/80 hover:text-[#FF6200] transition-colors py-2 text-sm font-medium"
              >
                {link.label}
              </Link>
            ))}
            <Link
              href="/services/"
              onClick={() => setOpen(false)}
              className="block w-full text-center px-5 py-2.5 bg-[#FF6200] text-white text-sm font-semibold rounded mt-2"
            >
              Get Started
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}
