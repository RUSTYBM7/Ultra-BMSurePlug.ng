"use client";

import Link from "next/link";
import { Play } from "lucide-react";

const links = [
  { href: "/services/", label: "Services" },
  { href: "/plans/", label: "Plans" },
  { href: "/marketplace/", label: "Marketplace" },
  { href: "/dashboard/", label: "Dashboard" },
  { href: "/reseller/", label: "Reseller" },
  { href: "/giveaway/", label: "Giveaway" },
];

export default function Footer() {
  return (
    <footer className="bg-[#0A0A0A] border-t-2 border-[#FF6200]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-1 group">
            <span className="text-white font-bold text-lg tracking-tight" style={{ fontFamily: "'Montserrat', sans-serif" }}>
              bmsocial
            </span>
            <span className="relative flex items-center">
              <span className="text-[#FF6200] font-bebas text-2xl leading-none">hub</span>
              <span className="absolute -right-3 top-1/2 -translate-y-1/2 w-3 h-3 bg-[#FF6200] rounded-full flex items-center justify-center">
                <Play className="w-1.5 h-1.5 text-white fill-white" />
              </span>
            </span>
          </Link>

          {/* Nav Links */}
          <div className="flex flex-wrap justify-center gap-6">
            {links.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="text-sm text-white/60 hover:text-[#FF6200] transition-colors"
              >
                {link.label}
              </Link>
            ))}
          </div>

          {/* URL */}
          <div className="text-white font-medium text-sm">
            www.bmsureplug.ng
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-white/10 text-center">
          <p className="text-white/40 text-xs">
            &copy; {new Date().getFullYear()} BMsureplug.ng — Social Media Growth Studio. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
