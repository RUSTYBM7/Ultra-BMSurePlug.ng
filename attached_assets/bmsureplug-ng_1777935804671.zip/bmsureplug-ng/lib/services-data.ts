export type Tier = 'Fast' | 'Plus' | 'Pro' | 'Steady' | 'Premium' | 'Elite';

export interface Service {
  id: string;
  platform: string;
  platformIcon: string;
  serviceType: string;
  tier: Tier;
  description: string;
  pricePer1k: number;
  minOrder: number;
  maxOrder: number;
  deliveryTime: string;
  refillGuarantee: boolean;
  features: string[];
}

export interface Platform {
  name: string;
  icon: string;
  color: string;
  services: Service[];
}

export const tiers: Tier[] = ['Fast', 'Plus', 'Pro', 'Steady', 'Premium', 'Elite'];

export const tierInfo: Record<Tier, { name: string; badge: string; desc: string; color: string }> = {
  Fast: { name: 'Fast', badge: '⚡ Fast Delivery', desc: 'Starts in minutes. Best for quick boosts.', color: '#22c55e' },
  Plus: { name: 'Plus', badge: '⭐ Best Value', desc: 'Balanced speed & quality with refill.', color: '#3b82f6' },
  Pro: { name: 'Pro', badge: '🔥 Popular', desc: 'Higher quality with better retention.', color: '#f59e0b' },
  Steady: { name: 'Steady', badge: '🛡️ Stable', desc: 'Gradual delivery. Most natural growth.', color: '#8b5cf6' },
  Premium: { name: 'Premium', badge: '💎 Premium', desc: 'Top-tier quality. Near-zero drop.', color: '#ec4899' },
  Elite: { name: 'Elite', badge: '👑 Elite', desc: 'Maximum quality. VIP support.', color: '#FF6200' },
};

export const platforms: Platform[] = [
  {
    name: 'Instagram',
    icon: 'Instagram',
    color: '#E4405F',
    services: [
      { id: 'ig-fol-fast', platform: 'Instagram', platformIcon: 'Instagram', serviceType: 'Followers', tier: 'Fast', description: 'Real-looking followers, fast delivery', pricePer1k: 510, minOrder: 100, maxOrder: 50000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Real profiles', 'No password', 'Instant start'] },
      { id: 'ig-fol-plus', platform: 'Instagram', platformIcon: 'Instagram', serviceType: 'Followers', tier: 'Plus', description: 'High-quality followers with profile pics', pricePer1k: 725, minOrder: 100, maxOrder: 100000, deliveryTime: '2-12 hours', refillGuarantee: true, features: ['HQ profiles', 'Profile pictures', '30-day refill'] },
      { id: 'ig-fol-pro', platform: 'Instagram', platformIcon: 'Instagram', serviceType: 'Followers', tier: 'Pro', description: 'Active-looking followers, better retention', pricePer1k: 1015, minOrder: 200, maxOrder: 100000, deliveryTime: '6-24 hours', refillGuarantee: true, features: ['Active appearance', 'Low drop', '60-day refill'] },
      { id: 'ig-fol-steady', platform: 'Instagram', platformIcon: 'Instagram', serviceType: 'Followers', tier: 'Steady', description: 'Gradual delivery for natural growth', pricePer1k: 1300, minOrder: 500, maxOrder: 50000, deliveryTime: '1-3 days', refillGuarantee: true, features: ['Drip-feed', 'Organic look', '90-day refill'] },
      { id: 'ig-fol-prem', platform: 'Instagram', platformIcon: 'Instagram', serviceType: 'Followers', tier: 'Premium', description: 'Near-zero drop premium followers', pricePer1k: 1740, minOrder: 500, maxOrder: 50000, deliveryTime: '12-48 hours', refillGuarantee: true, features: ['Premium quality', 'Near-zero drop', 'Lifetime refill'] },
      { id: 'ig-fol-elite', platform: 'Instagram', platformIcon: 'Instagram', serviceType: 'Followers', tier: 'Elite', description: 'Maximum quality, VIP-tier followers', pricePer1k: 2320, minOrder: 1000, maxOrder: 25000, deliveryTime: '24-72 hours', refillGuarantee: true, features: ['Elite quality', 'VIP support', 'Lifetime refill'] },

      { id: 'ig-lik-fast', platform: 'Instagram', platformIcon: 'Instagram', serviceType: 'Likes', tier: 'Fast', description: 'Quick likes for posts & reels', pricePer1k: 290, minOrder: 50, maxOrder: 100000, deliveryTime: 'Instant-1 hour', refillGuarantee: true, features: ['Instant start', 'Posts & reels', 'No password'] },
      { id: 'ig-lik-plus', platform: 'Instagram', platformIcon: 'Instagram', serviceType: 'Likes', tier: 'Plus', description: 'High-quality likes from real accounts', pricePer1k: 435, minOrder: 50, maxOrder: 200000, deliveryTime: '5-30 min', refillGuarantee: true, features: ['HQ accounts', 'Split available', '30-day refill'] },
      { id: 'ig-lik-pro', platform: 'Instagram', platformIcon: 'Instagram', serviceType: 'Likes', tier: 'Pro', description: 'Pro-grade likes with better spread', pricePer1k: 580, minOrder: 100, maxOrder: 200000, deliveryTime: '10-60 min', refillGuarantee: true, features: ['Better spread', 'Low drop', '60-day refill'] },
      { id: 'ig-lik-steady', platform: 'Instagram', platformIcon: 'Instagram', serviceType: 'Likes', tier: 'Steady', description: 'Gradual likes for organic appearance', pricePer1k: 725, minOrder: 200, maxOrder: 100000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Drip-feed', 'Organic look', '90-day refill'] },
      { id: 'ig-lik-prem', platform: 'Instagram', platformIcon: 'Instagram', serviceType: 'Likes', tier: 'Premium', description: 'Premium likes from aged accounts', pricePer1k: 1015, minOrder: 200, maxOrder: 100000, deliveryTime: '30 min - 3 hours', refillGuarantee: true, features: ['Aged accounts', 'Near-zero drop', 'Lifetime refill'] },
      { id: 'ig-lik-elite', platform: 'Instagram', platformIcon: 'Instagram', serviceType: 'Likes', tier: 'Elite', description: 'Elite-tier engagement likes', pricePer1k: 1450, minOrder: 500, maxOrder: 50000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Elite accounts', 'VIP support', 'Lifetime refill'] },

      { id: 'ig-vie-fast', platform: 'Instagram', platformIcon: 'Instagram', serviceType: 'Views', tier: 'Fast', description: 'Fast views for reels, stories & posts', pricePer1k: 145, minOrder: 100, maxOrder: 1000000, deliveryTime: 'Instant-30 min', refillGuarantee: false, features: ['Reels & posts', 'Stories', 'Instant start'] },
      { id: 'ig-vie-plus', platform: 'Instagram', platformIcon: 'Instagram', serviceType: 'Views', tier: 'Plus', description: 'High-retention views', pricePer1k: 220, minOrder: 100, maxOrder: 1000000, deliveryTime: '5-60 min', refillGuarantee: false, features: ['HQ views', 'Better retention', 'Split available'] },
      { id: 'ig-vie-pro', platform: 'Instagram', platformIcon: 'Instagram', serviceType: 'Views', tier: 'Pro', description: 'Pro views with improved watch time', pricePer1k: 290, minOrder: 500, maxOrder: 500000, deliveryTime: '10 min - 2 hours', refillGuarantee: false, features: ['Improved retention', 'Low drop', 'Analytics safe'] },
      { id: 'ig-vie-steady', platform: 'Instagram', platformIcon: 'Instagram', serviceType: 'Views', tier: 'Steady', description: 'Steady drip views for natural reach', pricePer1k: 435, minOrder: 1000, maxOrder: 500000, deliveryTime: '1-12 hours', refillGuarantee: false, features: ['Drip-feed', 'Organic pattern', 'Safe delivery'] },
      { id: 'ig-vie-prem', platform: 'Instagram', platformIcon: 'Instagram', serviceType: 'Views', tier: 'Premium', description: 'Premium high-retention views', pricePer1k: 580, minOrder: 1000, maxOrder: 250000, deliveryTime: '30 min - 6 hours', refillGuarantee: false, features: ['High retention', 'Aged accounts', 'Best for reels'] },
      { id: 'ig-vie-elite', platform: 'Instagram', platformIcon: 'Instagram', serviceType: 'Views', tier: 'Elite', description: 'Elite views with maximum retention', pricePer1k: 870, minOrder: 2000, maxOrder: 100000, deliveryTime: '1-12 hours', refillGuarantee: false, features: ['Max retention', 'VIP delivery', 'Monetization safe'] },

      { id: 'ig-com-fast', platform: 'Instagram', platformIcon: 'Instagram', serviceType: 'Comments', tier: 'Fast', description: 'Random/generic comments', pricePer1k: 1450, minOrder: 10, maxOrder: 5000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Random comments', 'Instant start', 'No password'] },
      { id: 'ig-com-plus', platform: 'Instagram', platformIcon: 'Instagram', serviceType: 'Comments', tier: 'Plus', description: 'Relevant emoji + text comments', pricePer1k: 2175, minOrder: 10, maxOrder: 10000, deliveryTime: '2-12 hours', refillGuarantee: true, features: ['Emoji + text', 'Relevant', '30-day refill'] },
      { id: 'ig-com-pro', platform: 'Instagram', platformIcon: 'Instagram', serviceType: 'Comments', tier: 'Pro', description: 'Custom comments you write', pricePer1k: 2900, minOrder: 5, maxOrder: 5000, deliveryTime: '6-24 hours', refillGuarantee: true, features: ['Custom text', 'Your choice', '60-day refill'] },
      { id: 'ig-com-steady', platform: 'Instagram', platformIcon: 'Instagram', serviceType: 'Comments', tier: 'Steady', description: 'Gradual custom comments', pricePer1k: 3625, minOrder: 10, maxOrder: 3000, deliveryTime: '12-48 hours', refillGuarantee: true, features: ['Drip-feed', 'Custom text', '90-day refill'] },
      { id: 'ig-com-prem', platform: 'Instagram', platformIcon: 'Instagram', serviceType: 'Comments', tier: 'Premium', description: 'Premium custom from aged accounts', pricePer1k: 5075, minOrder: 10, maxOrder: 2000, deliveryTime: '12-48 hours', refillGuarantee: true, features: ['Aged accounts', 'High quality', 'Lifetime refill'] },
      { id: 'ig-com-elite', platform: 'Instagram', platformIcon: 'Instagram', serviceType: 'Comments', tier: 'Elite', description: 'Elite custom comments, VIP handling', pricePer1k: 7250, minOrder: 20, maxOrder: 1000, deliveryTime: '24-72 hours', refillGuarantee: true, features: ['Elite quality', 'VIP support', 'Lifetime refill'] },

      { id: 'ig-sav-fast', platform: 'Instagram', platformIcon: 'Instagram', serviceType: 'Saves', tier: 'Fast', description: 'Fast post saves', pricePer1k: 290, minOrder: 50, maxOrder: 50000, deliveryTime: 'Instant-2 hours', refillGuarantee: true, features: ['Instant start', 'Post saves', 'No password'] },
      { id: 'ig-sav-plus', platform: 'Instagram', platformIcon: 'Instagram', serviceType: 'Saves', tier: 'Plus', description: 'High-quality saves', pricePer1k: 435, minOrder: 50, maxOrder: 100000, deliveryTime: '30 min - 4 hours', refillGuarantee: true, features: ['HQ accounts', 'Better retention', '30-day refill'] },
      { id: 'ig-sav-pro', platform: 'Instagram', platformIcon: 'Instagram', serviceType: 'Saves', tier: 'Pro', description: 'Pro saves for algorithm boost', pricePer1k: 580, minOrder: 100, maxOrder: 50000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Algorithm boost', 'Low drop', '60-day refill'] },
      { id: 'ig-sav-steady', platform: 'Instagram', platformIcon: 'Instagram', serviceType: 'Saves', tier: 'Steady', description: 'Gradual saves, organic pattern', pricePer1k: 725, minOrder: 200, maxOrder: 30000, deliveryTime: '3-12 hours', refillGuarantee: true, features: ['Drip-feed', 'Organic look', '90-day refill'] },
      { id: 'ig-sav-prem', platform: 'Instagram', platformIcon: 'Instagram', serviceType: 'Saves', tier: 'Premium', description: 'Premium saves from real accounts', pricePer1k: 1015, minOrder: 200, maxOrder: 20000, deliveryTime: '6-24 hours', refillGuarantee: true, features: ['Real accounts', 'Near-zero drop', 'Lifetime refill'] },
      { id: 'ig-sav-elite', platform: 'Instagram', platformIcon: 'Instagram', serviceType: 'Saves', tier: 'Elite', description: 'Elite saves, maximum impact', pricePer1k: 1450, minOrder: 500, maxOrder: 10000, deliveryTime: '12-48 hours', refillGuarantee: true, features: ['Elite quality', 'VIP support', 'Lifetime refill'] },
    ]
  },
  {
    name: 'TikTok',
    icon: 'Music2',
    color: '#000000',
    services: [
      { id: 'tt-fol-fast', platform: 'TikTok', platformIcon: 'Music2', serviceType: 'Followers', tier: 'Fast', description: 'Fast TikTok followers', pricePer1k: 580, minOrder: 100, maxOrder: 50000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Real-looking', 'Instant start', 'No password'] },
      { id: 'tt-fol-plus', platform: 'TikTok', platformIcon: 'Music2', serviceType: 'Followers', tier: 'Plus', description: 'HQ TikTok followers', pricePer1k: 870, minOrder: 100, maxOrder: 100000, deliveryTime: '2-12 hours', refillGuarantee: true, features: ['HQ profiles', 'Profile pics', '30-day refill'] },
      { id: 'tt-fol-pro', platform: 'TikTok', platformIcon: 'Music2', serviceType: 'Followers', tier: 'Pro', description: 'Pro followers, better retention', pricePer1k: 1160, minOrder: 200, maxOrder: 100000, deliveryTime: '6-24 hours', refillGuarantee: true, features: ['Better retention', 'Low drop', '60-day refill'] },
      { id: 'tt-fol-steady', platform: 'TikTok', platformIcon: 'Music2', serviceType: 'Followers', tier: 'Steady', description: 'Steady growth followers', pricePer1k: 1450, minOrder: 500, maxOrder: 50000, deliveryTime: '1-3 days', refillGuarantee: true, features: ['Drip-feed', 'Organic look', '90-day refill'] },
      { id: 'tt-fol-prem', platform: 'TikTok', platformIcon: 'Music2', serviceType: 'Followers', tier: 'Premium', description: 'Premium near-zero drop', pricePer1k: 2030, minOrder: 500, maxOrder: 30000, deliveryTime: '12-48 hours', refillGuarantee: true, features: ['Near-zero drop', 'Aged accounts', 'Lifetime refill'] },
      { id: 'tt-fol-elite', platform: 'TikTok', platformIcon: 'Music2', serviceType: 'Followers', tier: 'Elite', description: 'Elite TikTok followers', pricePer1k: 2900, minOrder: 1000, maxOrder: 20000, deliveryTime: '24-72 hours', refillGuarantee: true, features: ['Elite quality', 'VIP support', 'Lifetime refill'] },

      { id: 'tt-lik-fast', platform: 'TikTok', platformIcon: 'Music2', serviceType: 'Likes', tier: 'Fast', description: 'Fast TikTok likes', pricePer1k: 363, minOrder: 50, maxOrder: 200000, deliveryTime: 'Instant-1 hour', refillGuarantee: true, features: ['Instant start', 'All content', 'No password'] },
      { id: 'tt-lik-plus', platform: 'TikTok', platformIcon: 'Music2', serviceType: 'Likes', tier: 'Plus', description: 'HQ likes from real accounts', pricePer1k: 508, minOrder: 50, maxOrder: 300000, deliveryTime: '5-30 min', refillGuarantee: true, features: ['HQ accounts', 'Split available', '30-day refill'] },
      { id: 'tt-lik-pro', platform: 'TikTok', platformIcon: 'Music2', serviceType: 'Likes', tier: 'Pro', description: 'Pro likes with spread', pricePer1k: 725, minOrder: 100, maxOrder: 300000, deliveryTime: '10-60 min', refillGuarantee: true, features: ['Better spread', 'Low drop', '60-day refill'] },
      { id: 'tt-lik-steady', platform: 'TikTok', platformIcon: 'Music2', serviceType: 'Likes', tier: 'Steady', description: 'Gradual likes', pricePer1k: 870, minOrder: 200, maxOrder: 150000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Drip-feed', 'Organic look', '90-day refill'] },
      { id: 'tt-lik-prem', platform: 'TikTok', platformIcon: 'Music2', serviceType: 'Likes', tier: 'Premium', description: 'Premium aged-account likes', pricePer1k: 1160, minOrder: 200, maxOrder: 100000, deliveryTime: '30 min - 3 hours', refillGuarantee: true, features: ['Aged accounts', 'Near-zero drop', 'Lifetime refill'] },
      { id: 'tt-lik-elite', platform: 'TikTok', platformIcon: 'Music2', serviceType: 'Likes', tier: 'Elite', description: 'Elite TikTok likes', pricePer1k: 1740, minOrder: 500, maxOrder: 50000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Elite accounts', 'VIP support', 'Lifetime refill'] },

      { id: 'tt-vie-fast', platform: 'TikTok', platformIcon: 'Music2', serviceType: 'Views', tier: 'Fast', description: 'Fast TikTok views', pricePer1k: 218, minOrder: 100, maxOrder: 1000000, deliveryTime: 'Instant-30 min', refillGuarantee: false, features: ['Instant start', 'All videos', 'No password'] },
      { id: 'tt-vie-plus', platform: 'TikTok', platformIcon: 'Music2', serviceType: 'Views', tier: 'Plus', description: 'HQ views with retention', pricePer1k: 290, minOrder: 100, maxOrder: 1000000, deliveryTime: '5-60 min', refillGuarantee: false, features: ['Better retention', 'Split available', 'Analytics safe'] },
      { id: 'tt-vie-pro', platform: 'TikTok', platformIcon: 'Music2', serviceType: 'Views', tier: 'Pro', description: 'Pro views, improved watch time', pricePer1k: 435, minOrder: 500, maxOrder: 500000, deliveryTime: '10 min - 2 hours', refillGuarantee: false, features: ['Improved retention', 'Low drop', 'For you safe'] },
      { id: 'tt-vie-steady', platform: 'TikTok', platformIcon: 'Music2', serviceType: 'Views', tier: 'Steady', description: 'Steady drip views', pricePer1k: 580, minOrder: 1000, maxOrder: 500000, deliveryTime: '1-12 hours', refillGuarantee: false, features: ['Drip-feed', 'Organic pattern', 'Safe delivery'] },
      { id: 'tt-vie-prem', platform: 'TikTok', platformIcon: 'Music2', serviceType: 'Views', tier: 'Premium', description: 'Premium high-retention views', pricePer1k: 725, minOrder: 1000, maxOrder: 250000, deliveryTime: '30 min - 6 hours', refillGuarantee: false, features: ['High retention', 'Aged accounts', 'Best for viral'] },
      { id: 'tt-vie-elite', platform: 'TikTok', platformIcon: 'Music2', serviceType: 'Views', tier: 'Elite', description: 'Elite views, max retention', pricePer1k: 1015, minOrder: 2000, maxOrder: 100000, deliveryTime: '1-12 hours', refillGuarantee: false, features: ['Max retention', 'VIP delivery', 'Monetization safe'] },

      { id: 'tt-sha-fast', platform: 'TikTok', platformIcon: 'Music2', serviceType: 'Shares', tier: 'Fast', description: 'Fast shares', pricePer1k: 435, minOrder: 50, maxOrder: 50000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Instant start', 'All videos', 'No password'] },
      { id: 'tt-sha-plus', platform: 'TikTok', platformIcon: 'Music2', serviceType: 'Shares', tier: 'Plus', description: 'HQ shares', pricePer1k: 580, minOrder: 50, maxOrder: 100000, deliveryTime: '2-12 hours', refillGuarantee: true, features: ['HQ accounts', 'Better spread', '30-day refill'] },
      { id: 'tt-sha-pro', platform: 'TikTok', platformIcon: 'Music2', serviceType: 'Shares', tier: 'Pro', description: 'Pro shares', pricePer1k: 725, minOrder: 100, maxOrder: 50000, deliveryTime: '6-24 hours', refillGuarantee: true, features: ['Better retention', 'Low drop', '60-day refill'] },
      { id: 'tt-sha-steady', platform: 'TikTok', platformIcon: 'Music2', serviceType: 'Shares', tier: 'Steady', description: 'Steady shares', pricePer1k: 1015, minOrder: 200, maxOrder: 30000, deliveryTime: '12-48 hours', refillGuarantee: true, features: ['Drip-feed', 'Organic look', '90-day refill'] },
      { id: 'tt-sha-prem', platform: 'TikTok', platformIcon: 'Music2', serviceType: 'Shares', tier: 'Premium', description: 'Premium shares', pricePer1k: 1300, minOrder: 200, maxOrder: 20000, deliveryTime: '12-48 hours', refillGuarantee: true, features: ['Aged accounts', 'Near-zero drop', 'Lifetime refill'] },
      { id: 'tt-sha-elite', platform: 'TikTok', platformIcon: 'Music2', serviceType: 'Shares', tier: 'Elite', description: 'Elite shares', pricePer1k: 1740, minOrder: 500, maxOrder: 10000, deliveryTime: '24-72 hours', refillGuarantee: true, features: ['Elite quality', 'VIP support', 'Lifetime refill'] },
    ]
  },
  {
    name: 'YouTube',
    icon: 'Youtube',
    color: '#FF0000',
    services: [
      { id: 'yt-sub-fast', platform: 'YouTube', platformIcon: 'Youtube', serviceType: 'Subscribers', tier: 'Fast', description: 'Fast YouTube subscribers', pricePer1k: 1740, minOrder: 50, maxOrder: 10000, deliveryTime: '6-24 hours', refillGuarantee: true, features: ['Real-looking', 'No password', 'Instant start'] },
      { id: 'yt-sub-plus', platform: 'YouTube', platformIcon: 'Youtube', serviceType: 'Subscribers', tier: 'Plus', description: 'HQ subscribers', pricePer1k: 2465, minOrder: 100, maxOrder: 20000, deliveryTime: '12-48 hours', refillGuarantee: true, features: ['HQ profiles', 'Better retention', '30-day refill'] },
      { id: 'yt-sub-pro', platform: 'YouTube', platformIcon: 'Youtube', serviceType: 'Subscribers', tier: 'Pro', description: 'Pro subscribers, low drop', pricePer1k: 3190, minOrder: 100, maxOrder: 20000, deliveryTime: '1-3 days', refillGuarantee: true, features: ['Low drop', 'Active look', '60-day refill'] },
      { id: 'yt-sub-steady', platform: 'YouTube', platformIcon: 'Youtube', serviceType: 'Subscribers', tier: 'Steady', description: 'Steady subscriber growth', pricePer1k: 4350, minOrder: 200, maxOrder: 10000, deliveryTime: '2-5 days', refillGuarantee: true, features: ['Drip-feed', 'Organic look', '90-day refill'] },
      { id: 'yt-sub-prem', platform: 'YouTube', platformIcon: 'Youtube', serviceType: 'Subscribers', tier: 'Premium', description: 'Premium near-zero drop', pricePer1k: 5800, minOrder: 200, maxOrder: 5000, deliveryTime: '3-7 days', refillGuarantee: true, features: ['Near-zero drop', 'Aged accounts', 'Lifetime refill'] },
      { id: 'yt-sub-elite', platform: 'YouTube', platformIcon: 'Youtube', serviceType: 'Subscribers', tier: 'Elite', description: 'Elite subscribers', pricePer1k: 7250, minOrder: 500, maxOrder: 3000, deliveryTime: '5-10 days', refillGuarantee: true, features: ['Elite quality', 'VIP support', 'Lifetime refill'] },

      { id: 'yt-vie-fast', platform: 'YouTube', platformIcon: 'Youtube', serviceType: 'Views', tier: 'Fast', description: 'Fast video views', pricePer1k: 725, minOrder: 500, maxOrder: 500000, deliveryTime: '1-6 hours', refillGuarantee: false, features: ['Instant start', 'All videos', 'No password'] },
      { id: 'yt-vie-plus', platform: 'YouTube', platformIcon: 'Youtube', serviceType: 'Views', tier: 'Plus', description: 'HQ views with retention', pricePer1k: 1015, minOrder: 500, maxOrder: 500000, deliveryTime: '2-12 hours', refillGuarantee: false, features: ['Better retention', 'Split available', 'Monetization safe'] },
      { id: 'yt-vie-pro', platform: 'YouTube', platformIcon: 'Youtube', serviceType: 'Views', tier: 'Pro', description: 'Pro high-retention views', pricePer1k: 1450, minOrder: 1000, maxOrder: 300000, deliveryTime: '6-24 hours', refillGuarantee: false, features: ['High retention', 'Low drop', 'Analytics safe'] },
      { id: 'yt-vie-steady', platform: 'YouTube', platformIcon: 'Youtube', serviceType: 'Views', tier: 'Steady', description: 'Steady drip views', pricePer1k: 1885, minOrder: 2000, maxOrder: 200000, deliveryTime: '1-3 days', refillGuarantee: false, features: ['Drip-feed', 'Organic pattern', 'Safe delivery'] },
      { id: 'yt-vie-prem', platform: 'YouTube', platformIcon: 'Youtube', serviceType: 'Views', tier: 'Premium', description: 'Premium views, max retention', pricePer1k: 2465, minOrder: 2000, maxOrder: 100000, deliveryTime: '12-48 hours', refillGuarantee: false, features: ['Max retention', 'Aged accounts', 'Best for monetization'] },
      { id: 'yt-vie-elite', platform: 'YouTube', platformIcon: 'Youtube', serviceType: 'Views', tier: 'Elite', description: 'Elite views', pricePer1k: 3190, minOrder: 5000, maxOrder: 50000, deliveryTime: '1-3 days', refillGuarantee: false, features: ['Elite quality', 'VIP delivery', 'Monetization safe'] },

      { id: 'yt-lik-fast', platform: 'YouTube', platformIcon: 'Youtube', serviceType: 'Likes', tier: 'Fast', description: 'Fast likes', pricePer1k: 580, minOrder: 50, maxOrder: 100000, deliveryTime: 'Instant-2 hours', refillGuarantee: true, features: ['Instant start', 'All videos', 'No password'] },
      { id: 'yt-lik-plus', platform: 'YouTube', platformIcon: 'Youtube', serviceType: 'Likes', tier: 'Plus', description: 'HQ likes', pricePer1k: 870, minOrder: 50, maxOrder: 200000, deliveryTime: '30 min - 4 hours', refillGuarantee: true, features: ['HQ accounts', 'Better retention', '30-day refill'] },
      { id: 'yt-lik-pro', platform: 'YouTube', platformIcon: 'Youtube', serviceType: 'Likes', tier: 'Pro', description: 'Pro likes', pricePer1k: 1160, minOrder: 100, maxOrder: 100000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Low drop', 'Active look', '60-day refill'] },
      { id: 'yt-lik-steady', platform: 'YouTube', platformIcon: 'Youtube', serviceType: 'Likes', tier: 'Steady', description: 'Steady likes', pricePer1k: 1450, minOrder: 200, maxOrder: 50000, deliveryTime: '3-12 hours', refillGuarantee: true, features: ['Drip-feed', 'Organic look', '90-day refill'] },
      { id: 'yt-lik-prem', platform: 'YouTube', platformIcon: 'Youtube', serviceType: 'Likes', tier: 'Premium', description: 'Premium likes', pricePer1k: 1885, minOrder: 200, maxOrder: 30000, deliveryTime: '6-24 hours', refillGuarantee: true, features: ['Aged accounts', 'Near-zero drop', 'Lifetime refill'] },
      { id: 'yt-lik-elite', platform: 'YouTube', platformIcon: 'Youtube', serviceType: 'Likes', tier: 'Elite', description: 'Elite likes', pricePer1k: 2465, minOrder: 500, maxOrder: 15000, deliveryTime: '12-48 hours', refillGuarantee: true, features: ['Elite quality', 'VIP support', 'Lifetime refill'] },

      { id: 'yt-com-fast', platform: 'YouTube', platformIcon: 'Youtube', serviceType: 'Comments', tier: 'Fast', description: 'Random comments', pricePer1k: 2175, minOrder: 10, maxOrder: 5000, deliveryTime: '2-12 hours', refillGuarantee: true, features: ['Random text', 'Instant start', 'No password'] },
      { id: 'yt-com-plus', platform: 'YouTube', platformIcon: 'Youtube', serviceType: 'Comments', tier: 'Plus', description: 'Relevant comments', pricePer1k: 2900, minOrder: 10, maxOrder: 10000, deliveryTime: '6-24 hours', refillGuarantee: true, features: ['Relevant text', 'Better quality', '30-day refill'] },
      { id: 'yt-com-pro', platform: 'YouTube', platformIcon: 'Youtube', serviceType: 'Comments', tier: 'Pro', description: 'Custom comments', pricePer1k: 3625, minOrder: 5, maxOrder: 5000, deliveryTime: '12-48 hours', refillGuarantee: true, features: ['Custom text', 'Your choice', '60-day refill'] },
      { id: 'yt-com-steady', platform: 'YouTube', platformIcon: 'Youtube', serviceType: 'Comments', tier: 'Steady', description: 'Gradual custom comments', pricePer1k: 4350, minOrder: 10, maxOrder: 3000, deliveryTime: '1-3 days', refillGuarantee: true, features: ['Drip-feed', 'Custom text', '90-day refill'] },
      { id: 'yt-com-prem', platform: 'YouTube', platformIcon: 'Youtube', serviceType: 'Comments', tier: 'Premium', description: 'Premium custom comments', pricePer1k: 5800, minOrder: 10, maxOrder: 2000, deliveryTime: '2-5 days', refillGuarantee: true, features: ['Aged accounts', 'High quality', 'Lifetime refill'] },
      { id: 'yt-com-elite', platform: 'YouTube', platformIcon: 'Youtube', serviceType: 'Comments', tier: 'Elite', description: 'Elite custom comments', pricePer1k: 7250, minOrder: 20, maxOrder: 1000, deliveryTime: '3-7 days', refillGuarantee: true, features: ['Elite quality', 'VIP support', 'Lifetime refill'] },
    ]
  },
  {
    name: 'Twitter / X',
    icon: 'Twitter',
    color: '#000000',
    services: [
      { id: 'tx-fol-fast', platform: 'Twitter / X', platformIcon: 'Twitter', serviceType: 'Followers', tier: 'Fast', description: 'Fast X followers', pricePer1k: 725, minOrder: 100, maxOrder: 50000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Real-looking', 'Instant start', 'No password'] },
      { id: 'tx-fol-plus', platform: 'Twitter / X', platformIcon: 'Twitter', serviceType: 'Followers', tier: 'Plus', description: 'HQ X followers', pricePer1k: 1015, minOrder: 100, maxOrder: 100000, deliveryTime: '2-12 hours', refillGuarantee: true, features: ['HQ profiles', 'Better retention', '30-day refill'] },
      { id: 'tx-fol-pro', platform: 'Twitter / X', platformIcon: 'Twitter', serviceType: 'Followers', tier: 'Pro', description: 'Pro followers, low drop', pricePer1k: 1300, minOrder: 200, maxOrder: 100000, deliveryTime: '6-24 hours', refillGuarantee: true, features: ['Low drop', 'Active look', '60-day refill'] },
      { id: 'tx-fol-steady', platform: 'Twitter / X', platformIcon: 'Twitter', serviceType: 'Followers', tier: 'Steady', description: 'Steady growth followers', pricePer1k: 1740, minOrder: 500, maxOrder: 50000, deliveryTime: '1-3 days', refillGuarantee: true, features: ['Drip-feed', 'Organic look', '90-day refill'] },
      { id: 'tx-fol-prem', platform: 'Twitter / X', platformIcon: 'Twitter', serviceType: 'Followers', tier: 'Premium', description: 'Premium near-zero drop', pricePer1k: 2320, minOrder: 500, maxOrder: 30000, deliveryTime: '12-48 hours', refillGuarantee: true, features: ['Near-zero drop', 'Aged accounts', 'Lifetime refill'] },
      { id: 'tx-fol-elite', platform: 'Twitter / X', platformIcon: 'Twitter', serviceType: 'Followers', tier: 'Elite', description: 'Elite X followers', pricePer1k: 2900, minOrder: 1000, maxOrder: 20000, deliveryTime: '24-72 hours', refillGuarantee: true, features: ['Elite quality', 'VIP support', 'Lifetime refill'] },

      { id: 'tx-lik-fast', platform: 'Twitter / X', platformIcon: 'Twitter', serviceType: 'Likes', tier: 'Fast', description: 'Fast tweet likes', pricePer1k: 435, minOrder: 50, maxOrder: 100000, deliveryTime: 'Instant-1 hour', refillGuarantee: true, features: ['Instant start', 'All tweets', 'No password'] },
      { id: 'tx-lik-plus', platform: 'Twitter / X', platformIcon: 'Twitter', serviceType: 'Likes', tier: 'Plus', description: 'HQ tweet likes', pricePer1k: 580, minOrder: 50, maxOrder: 200000, deliveryTime: '5-30 min', refillGuarantee: true, features: ['HQ accounts', 'Split available', '30-day refill'] },
      { id: 'tx-lik-pro', platform: 'Twitter / X', platformIcon: 'Twitter', serviceType: 'Likes', tier: 'Pro', description: 'Pro likes with spread', pricePer1k: 725, minOrder: 100, maxOrder: 200000, deliveryTime: '10-60 min', refillGuarantee: true, features: ['Better spread', 'Low drop', '60-day refill'] },
      { id: 'tx-lik-steady', platform: 'Twitter / X', platformIcon: 'Twitter', serviceType: 'Likes', tier: 'Steady', description: 'Gradual likes', pricePer1k: 1015, minOrder: 200, maxOrder: 100000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Drip-feed', 'Organic look', '90-day refill'] },
      { id: 'tx-lik-prem', platform: 'Twitter / X', platformIcon: 'Twitter', serviceType: 'Likes', tier: 'Premium', description: 'Premium aged-account likes', pricePer1k: 1300, minOrder: 200, maxOrder: 50000, deliveryTime: '30 min - 3 hours', refillGuarantee: true, features: ['Aged accounts', 'Near-zero drop', 'Lifetime refill'] },
      { id: 'tx-lik-elite', platform: 'Twitter / X', platformIcon: 'Twitter', serviceType: 'Likes', tier: 'Elite', description: 'Elite tweet likes', pricePer1k: 1740, minOrder: 500, maxOrder: 25000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Elite accounts', 'VIP support', 'Lifetime refill'] },

      { id: 'tx-ret-fast', platform: 'Twitter / X', platformIcon: 'Twitter', serviceType: 'Retweets', tier: 'Fast', description: 'Fast retweets', pricePer1k: 725, minOrder: 50, maxOrder: 50000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Instant start', 'All tweets', 'No password'] },
      { id: 'tx-ret-plus', platform: 'Twitter / X', platformIcon: 'Twitter', serviceType: 'Retweets', tier: 'Plus', description: 'HQ retweets', pricePer1k: 1015, minOrder: 50, maxOrder: 100000, deliveryTime: '2-12 hours', refillGuarantee: true, features: ['HQ accounts', 'Better spread', '30-day refill'] },
      { id: 'tx-ret-pro', platform: 'Twitter / X', platformIcon: 'Twitter', serviceType: 'Retweets', tier: 'Pro', description: 'Pro retweets', pricePer1k: 1300, minOrder: 100, maxOrder: 50000, deliveryTime: '6-24 hours', refillGuarantee: true, features: ['Low drop', 'Active look', '60-day refill'] },
      { id: 'tx-ret-steady', platform: 'Twitter / X', platformIcon: 'Twitter', serviceType: 'Retweets', tier: 'Steady', description: 'Steady retweets', pricePer1k: 1740, minOrder: 200, maxOrder: 30000, deliveryTime: '12-48 hours', refillGuarantee: true, features: ['Drip-feed', 'Organic look', '90-day refill'] },
      { id: 'tx-ret-prem', platform: 'Twitter / X', platformIcon: 'Twitter', serviceType: 'Retweets', tier: 'Premium', description: 'Premium retweets', pricePer1k: 2320, minOrder: 200, maxOrder: 20000, deliveryTime: '12-48 hours', refillGuarantee: true, features: ['Aged accounts', 'Near-zero drop', 'Lifetime refill'] },
      { id: 'tx-ret-elite', platform: 'Twitter / X', platformIcon: 'Twitter', serviceType: 'Retweets', tier: 'Elite', description: 'Elite retweets', pricePer1k: 2900, minOrder: 500, maxOrder: 10000, deliveryTime: '24-72 hours', refillGuarantee: true, features: ['Elite quality', 'VIP support', 'Lifetime refill'] },
    ]
  },
  {
    name: 'Facebook',
    icon: 'Facebook',
    color: '#1877F2',
    services: [
      { id: 'fb-lik-fast', platform: 'Facebook', platformIcon: 'Facebook', serviceType: 'Page Likes', tier: 'Fast', description: 'Fast page likes', pricePer1k: 655, minOrder: 100, maxOrder: 50000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Real-looking', 'Instant start', 'No password'] },
      { id: 'fb-lik-plus', platform: 'Facebook', platformIcon: 'Facebook', serviceType: 'Page Likes', tier: 'Plus', description: 'HQ page likes', pricePer1k: 870, minOrder: 100, maxOrder: 100000, deliveryTime: '2-12 hours', refillGuarantee: true, features: ['HQ profiles', 'Better retention', '30-day refill'] },
      { id: 'fb-lik-pro', platform: 'Facebook', platformIcon: 'Facebook', serviceType: 'Page Likes', tier: 'Pro', description: 'Pro page likes', pricePer1k: 1160, minOrder: 200, maxOrder: 100000, deliveryTime: '6-24 hours', refillGuarantee: true, features: ['Low drop', 'Active look', '60-day refill'] },
      { id: 'fb-lik-steady', platform: 'Facebook', platformIcon: 'Facebook', serviceType: 'Page Likes', tier: 'Steady', description: 'Steady page likes', pricePer1k: 1450, minOrder: 500, maxOrder: 50000, deliveryTime: '1-3 days', refillGuarantee: true, features: ['Drip-feed', 'Organic look', '90-day refill'] },
      { id: 'fb-lik-prem', platform: 'Facebook', platformIcon: 'Facebook', serviceType: 'Page Likes', tier: 'Premium', description: 'Premium page likes', pricePer1k: 2030, minOrder: 500, maxOrder: 30000, deliveryTime: '12-48 hours', refillGuarantee: true, features: ['Near-zero drop', 'Aged accounts', 'Lifetime refill'] },
      { id: 'fb-lik-elite', platform: 'Facebook', platformIcon: 'Facebook', serviceType: 'Page Likes', tier: 'Elite', description: 'Elite page likes', pricePer1k: 2610, minOrder: 1000, maxOrder: 20000, deliveryTime: '24-72 hours', refillGuarantee: true, features: ['Elite quality', 'VIP support', 'Lifetime refill'] },

      { id: 'fb-fol-fast', platform: 'Facebook', platformIcon: 'Facebook', serviceType: 'Profile Followers', tier: 'Fast', description: 'Fast profile followers', pricePer1k: 580, minOrder: 100, maxOrder: 50000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Instant start', 'All profiles', 'No password'] },
      { id: 'fb-fol-plus', platform: 'Facebook', platformIcon: 'Facebook', serviceType: 'Profile Followers', tier: 'Plus', description: 'HQ profile followers', pricePer1k: 725, minOrder: 100, maxOrder: 100000, deliveryTime: '2-12 hours', refillGuarantee: true, features: ['HQ accounts', 'Better retention', '30-day refill'] },
      { id: 'fb-fol-pro', platform: 'Facebook', platformIcon: 'Facebook', serviceType: 'Profile Followers', tier: 'Pro', description: 'Pro followers', pricePer1k: 1015, minOrder: 200, maxOrder: 50000, deliveryTime: '6-24 hours', refillGuarantee: true, features: ['Low drop', 'Active look', '60-day refill'] },
      { id: 'fb-fol-steady', platform: 'Facebook', platformIcon: 'Facebook', serviceType: 'Profile Followers', tier: 'Steady', description: 'Steady followers', pricePer1k: 1300, minOrder: 500, maxOrder: 30000, deliveryTime: '12-48 hours', refillGuarantee: true, features: ['Drip-feed', 'Organic look', '90-day refill'] },
      { id: 'fb-fol-prem', platform: 'Facebook', platformIcon: 'Facebook', serviceType: 'Profile Followers', tier: 'Premium', description: 'Premium followers', pricePer1k: 1740, minOrder: 500, maxOrder: 20000, deliveryTime: '12-48 hours', refillGuarantee: true, features: ['Aged accounts', 'Near-zero drop', 'Lifetime refill'] },
      { id: 'fb-fol-elite', platform: 'Facebook', platformIcon: 'Facebook', serviceType: 'Profile Followers', tier: 'Elite', description: 'Elite followers', pricePer1k: 2320, minOrder: 1000, maxOrder: 10000, deliveryTime: '24-72 hours', refillGuarantee: true, features: ['Elite quality', 'VIP support', 'Lifetime refill'] },

      { id: 'fb-pos-fast', platform: 'Facebook', platformIcon: 'Facebook', serviceType: 'Post Likes', tier: 'Fast', description: 'Fast post likes', pricePer1k: 290, minOrder: 50, maxOrder: 100000, deliveryTime: 'Instant-1 hour', refillGuarantee: true, features: ['Instant start', 'All posts', 'No password'] },
      { id: 'fb-pos-plus', platform: 'Facebook', platformIcon: 'Facebook', serviceType: 'Post Likes', tier: 'Plus', description: 'HQ post likes', pricePer1k: 435, minOrder: 50, maxOrder: 200000, deliveryTime: '5-30 min', refillGuarantee: true, features: ['HQ accounts', 'Split available', '30-day refill'] },
      { id: 'fb-pos-pro', platform: 'Facebook', platformIcon: 'Facebook', serviceType: 'Post Likes', tier: 'Pro', description: 'Pro post likes', pricePer1k: 580, minOrder: 100, maxOrder: 100000, deliveryTime: '10-60 min', refillGuarantee: true, features: ['Better spread', 'Low drop', '60-day refill'] },
      { id: 'fb-pos-steady', platform: 'Facebook', platformIcon: 'Facebook', serviceType: 'Post Likes', tier: 'Steady', description: 'Steady post likes', pricePer1k: 725, minOrder: 200, maxOrder: 50000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Drip-feed', 'Organic look', '90-day refill'] },
      { id: 'fb-pos-prem', platform: 'Facebook', platformIcon: 'Facebook', serviceType: 'Post Likes', tier: 'Premium', description: 'Premium post likes', pricePer1k: 1015, minOrder: 200, maxOrder: 30000, deliveryTime: '30 min - 3 hours', refillGuarantee: true, features: ['Aged accounts', 'Near-zero drop', 'Lifetime refill'] },
      { id: 'fb-pos-elite', platform: 'Facebook', platformIcon: 'Facebook', serviceType: 'Post Likes', tier: 'Elite', description: 'Elite post likes', pricePer1k: 1450, minOrder: 500, maxOrder: 15000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Elite accounts', 'VIP support', 'Lifetime refill'] },
    ]
  },
  {
    name: 'Telegram',
    icon: 'Send',
    color: '#0088cc',
    services: [
      { id: 'tg-mem-fast', platform: 'Telegram', platformIcon: 'Send', serviceType: 'Members', tier: 'Fast', description: 'Fast channel/group members', pricePer1k: 580, minOrder: 100, maxOrder: 50000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Real-looking', 'Instant start', 'No password'] },
      { id: 'tg-mem-plus', platform: 'Telegram', platformIcon: 'Send', serviceType: 'Members', tier: 'Plus', description: 'HQ members', pricePer1k: 870, minOrder: 100, maxOrder: 100000, deliveryTime: '2-12 hours', refillGuarantee: true, features: ['HQ profiles', 'Better retention', '30-day refill'] },
      { id: 'tg-mem-pro', platform: 'Telegram', platformIcon: 'Send', serviceType: 'Members', tier: 'Pro', description: 'Pro members', pricePer1k: 1160, minOrder: 200, maxOrder: 100000, deliveryTime: '6-24 hours', refillGuarantee: true, features: ['Low drop', 'Active look', '60-day refill'] },
      { id: 'tg-mem-steady', platform: 'Telegram', platformIcon: 'Send', serviceType: 'Members', tier: 'Steady', description: 'Steady members', pricePer1k: 1450, minOrder: 500, maxOrder: 50000, deliveryTime: '1-3 days', refillGuarantee: true, features: ['Drip-feed', 'Organic look', '90-day refill'] },
      { id: 'tg-mem-prem', platform: 'Telegram', platformIcon: 'Send', serviceType: 'Members', tier: 'Premium', description: 'Premium members', pricePer1k: 2030, minOrder: 500, maxOrder: 30000, deliveryTime: '12-48 hours', refillGuarantee: true, features: ['Near-zero drop', 'Aged accounts', 'Lifetime refill'] },
      { id: 'tg-mem-elite', platform: 'Telegram', platformIcon: 'Send', serviceType: 'Members', tier: 'Elite', description: 'Elite members', pricePer1k: 2610, minOrder: 1000, maxOrder: 20000, deliveryTime: '24-72 hours', refillGuarantee: true, features: ['Elite quality', 'VIP support', 'Lifetime refill'] },

      { id: 'tg-vie-fast', platform: 'Telegram', platformIcon: 'Send', serviceType: 'Post Views', tier: 'Fast', description: 'Fast post views', pricePer1k: 145, minOrder: 100, maxOrder: 1000000, deliveryTime: 'Instant-30 min', refillGuarantee: false, features: ['Instant start', 'All posts', 'No password'] },
      { id: 'tg-vie-plus', platform: 'Telegram', platformIcon: 'Send', serviceType: 'Post Views', tier: 'Plus', description: 'HQ post views', pricePer1k: 218, minOrder: 100, maxOrder: 500000, deliveryTime: '5-60 min', refillGuarantee: false, features: ['Better retention', 'Split available', 'Analytics safe'] },
      { id: 'tg-vie-pro', platform: 'Telegram', platformIcon: 'Send', serviceType: 'Post Views', tier: 'Pro', description: 'Pro post views', pricePer1k: 290, minOrder: 500, maxOrder: 300000, deliveryTime: '10 min - 2 hours', refillGuarantee: false, features: ['Improved retention', 'Low drop', 'Safe delivery'] },
      { id: 'tg-vie-steady', platform: 'Telegram', platformIcon: 'Send', serviceType: 'Post Views', tier: 'Steady', description: 'Steady views', pricePer1k: 435, minOrder: 1000, maxOrder: 200000, deliveryTime: '1-12 hours', refillGuarantee: false, features: ['Drip-feed', 'Organic pattern', 'Safe delivery'] },
      { id: 'tg-vie-prem', platform: 'Telegram', platformIcon: 'Send', serviceType: 'Post Views', tier: 'Premium', description: 'Premium views', pricePer1k: 580, minOrder: 1000, maxOrder: 100000, deliveryTime: '30 min - 6 hours', refillGuarantee: false, features: ['High retention', 'Aged accounts', 'Best for channels'] },
      { id: 'tg-vie-elite', platform: 'Telegram', platformIcon: 'Send', serviceType: 'Post Views', tier: 'Elite', description: 'Elite views', pricePer1k: 725, minOrder: 2000, maxOrder: 50000, deliveryTime: '1-12 hours', refillGuarantee: false, features: ['Max retention', 'VIP delivery', 'Monetization safe'] },

      { id: 'tg-rea-fast', platform: 'Telegram', platformIcon: 'Send', serviceType: 'Reactions', tier: 'Fast', description: 'Fast reactions', pricePer1k: 435, minOrder: 50, maxOrder: 50000, deliveryTime: 'Instant-2 hours', refillGuarantee: true, features: ['Instant start', 'All reactions', 'No password'] },
      { id: 'tg-rea-plus', platform: 'Telegram', platformIcon: 'Send', serviceType: 'Reactions', tier: 'Plus', description: 'HQ reactions', pricePer1k: 580, minOrder: 50, maxOrder: 100000, deliveryTime: '30 min - 4 hours', refillGuarantee: true, features: ['HQ accounts', 'All emojis', '30-day refill'] },
      { id: 'tg-rea-pro', platform: 'Telegram', platformIcon: 'Send', serviceType: 'Reactions', tier: 'Pro', description: 'Pro reactions', pricePer1k: 725, minOrder: 100, maxOrder: 50000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Low drop', 'All emojis', '60-day refill'] },
      { id: 'tg-rea-steady', platform: 'Telegram', platformIcon: 'Send', serviceType: 'Reactions', tier: 'Steady', description: 'Steady reactions', pricePer1k: 1015, minOrder: 200, maxOrder: 30000, deliveryTime: '3-12 hours', refillGuarantee: true, features: ['Drip-feed', 'Organic look', '90-day refill'] },
      { id: 'tg-rea-prem', platform: 'Telegram', platformIcon: 'Send', serviceType: 'Reactions', tier: 'Premium', description: 'Premium reactions', pricePer1k: 1300, minOrder: 200, maxOrder: 20000, deliveryTime: '6-24 hours', refillGuarantee: true, features: ['Aged accounts', 'Near-zero drop', 'Lifetime refill'] },
      { id: 'tg-rea-elite', platform: 'Telegram', platformIcon: 'Send', serviceType: 'Reactions', tier: 'Elite', description: 'Elite reactions', pricePer1k: 1740, minOrder: 500, maxOrder: 10000, deliveryTime: '12-48 hours', refillGuarantee: true, features: ['Elite quality', 'VIP support', 'Lifetime refill'] },
    ]
  },
  {
    name: 'Spotify',
    icon: 'Headphones',
    color: '#1DB954',
    services: [
      { id: 'sp-fol-fast', platform: 'Spotify', platformIcon: 'Headphones', serviceType: 'Followers', tier: 'Fast', description: 'Fast playlist/artist followers', pricePer1k: 870, minOrder: 100, maxOrder: 50000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Real-looking', 'Instant start', 'No password'] },
      { id: 'sp-fol-plus', platform: 'Spotify', platformIcon: 'Headphones', serviceType: 'Followers', tier: 'Plus', description: 'HQ followers', pricePer1k: 1160, minOrder: 100, maxOrder: 100000, deliveryTime: '2-12 hours', refillGuarantee: true, features: ['HQ profiles', 'Better retention', '30-day refill'] },
      { id: 'sp-fol-pro', platform: 'Spotify', platformIcon: 'Headphones', serviceType: 'Followers', tier: 'Pro', description: 'Pro followers', pricePer1k: 1450, minOrder: 200, maxOrder: 50000, deliveryTime: '6-24 hours', refillGuarantee: true, features: ['Low drop', 'Active look', '60-day refill'] },
      { id: 'sp-fol-steady', platform: 'Spotify', platformIcon: 'Headphones', serviceType: 'Followers', tier: 'Steady', description: 'Steady followers', pricePer1k: 1885, minOrder: 500, maxOrder: 30000, deliveryTime: '1-3 days', refillGuarantee: true, features: ['Drip-feed', 'Organic look', '90-day refill'] },
      { id: 'sp-fol-prem', platform: 'Spotify', platformIcon: 'Headphones', serviceType: 'Followers', tier: 'Premium', description: 'Premium followers', pricePer1k: 2465, minOrder: 500, maxOrder: 20000, deliveryTime: '12-48 hours', refillGuarantee: true, features: ['Near-zero drop', 'Aged accounts', 'Lifetime refill'] },
      { id: 'sp-fol-elite', platform: 'Spotify', platformIcon: 'Headphones', serviceType: 'Followers', tier: 'Elite', description: 'Elite followers', pricePer1k: 3190, minOrder: 1000, maxOrder: 10000, deliveryTime: '24-72 hours', refillGuarantee: true, features: ['Elite quality', 'VIP support', 'Lifetime refill'] },

      { id: 'sp-pla-fast', platform: 'Spotify', platformIcon: 'Headphones', serviceType: 'Plays', tier: 'Fast', description: 'Fast track plays', pricePer1k: 435, minOrder: 1000, maxOrder: 1000000, deliveryTime: '1-6 hours', refillGuarantee: false, features: ['Instant start', 'All tracks', 'No password'] },
      { id: 'sp-pla-plus', platform: 'Spotify', platformIcon: 'Headphones', serviceType: 'Plays', tier: 'Plus', description: 'HQ plays with retention', pricePer1k: 580, minOrder: 1000, maxOrder: 500000, deliveryTime: '2-12 hours', refillGuarantee: false, features: ['Better retention', 'Split available', 'Analytics safe'] },
      { id: 'sp-pla-pro', platform: 'Spotify', platformIcon: 'Headphones', serviceType: 'Plays', tier: 'Pro', description: 'Pro high-retention plays', pricePer1k: 725, minOrder: 2000, maxOrder: 300000, deliveryTime: '6-24 hours', refillGuarantee: false, features: ['High retention', 'Low drop', 'Safe delivery'] },
      { id: 'sp-pla-steady', platform: 'Spotify', platformIcon: 'Headphones', serviceType: 'Plays', tier: 'Steady', description: 'Steady plays', pricePer1k: 1015, minOrder: 5000, maxOrder: 200000, deliveryTime: '1-3 days', refillGuarantee: false, features: ['Drip-feed', 'Organic pattern', 'Safe delivery'] },
      { id: 'sp-pla-prem', platform: 'Spotify', platformIcon: 'Headphones', serviceType: 'Plays', tier: 'Premium', description: 'Premium plays', pricePer1k: 1300, minOrder: 5000, maxOrder: 100000, deliveryTime: '12-48 hours', refillGuarantee: false, features: ['Max retention', 'Aged accounts', 'Best for algorithm'] },
      { id: 'sp-pla-elite', platform: 'Spotify', platformIcon: 'Headphones', serviceType: 'Plays', tier: 'Elite', description: 'Elite plays', pricePer1k: 1740, minOrder: 10000, maxOrder: 50000, deliveryTime: '24-72 hours', refillGuarantee: false, features: ['Elite quality', 'VIP delivery', 'Monetization safe'] },

      { id: 'sp-sav-fast', platform: 'Spotify', platformIcon: 'Headphones', serviceType: 'Saves', tier: 'Fast', description: 'Fast saves', pricePer1k: 580, minOrder: 100, maxOrder: 50000, deliveryTime: 'Instant-2 hours', refillGuarantee: true, features: ['Instant start', 'All tracks', 'No password'] },
      { id: 'sp-sav-plus', platform: 'Spotify', platformIcon: 'Headphones', serviceType: 'Saves', tier: 'Plus', description: 'HQ saves', pricePer1k: 725, minOrder: 100, maxOrder: 100000, deliveryTime: '30 min - 4 hours', refillGuarantee: true, features: ['HQ accounts', 'Better retention', '30-day refill'] },
      { id: 'sp-sav-pro', platform: 'Spotify', platformIcon: 'Headphones', serviceType: 'Saves', tier: 'Pro', description: 'Pro saves', pricePer1k: 1015, minOrder: 200, maxOrder: 50000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Low drop', 'Active look', '60-day refill'] },
      { id: 'sp-sav-steady', platform: 'Spotify', platformIcon: 'Headphones', serviceType: 'Saves', tier: 'Steady', description: 'Steady saves', pricePer1k: 1300, minOrder: 500, maxOrder: 30000, deliveryTime: '3-12 hours', refillGuarantee: true, features: ['Drip-feed', 'Organic look', '90-day refill'] },
      { id: 'sp-sav-prem', platform: 'Spotify', platformIcon: 'Headphones', serviceType: 'Saves', tier: 'Premium', description: 'Premium saves', pricePer1k: 1740, minOrder: 500, maxOrder: 20000, deliveryTime: '6-24 hours', refillGuarantee: true, features: ['Aged accounts', 'Near-zero drop', 'Lifetime refill'] },
      { id: 'sp-sav-elite', platform: 'Spotify', platformIcon: 'Headphones', serviceType: 'Saves', tier: 'Elite', description: 'Elite saves', pricePer1k: 2320, minOrder: 1000, maxOrder: 10000, deliveryTime: '12-48 hours', refillGuarantee: true, features: ['Elite quality', 'VIP support', 'Lifetime refill'] },
    ]
  },
  {
    name: 'LinkedIn',
    icon: 'Linkedin',
    color: '#0A66C2',
    services: [
      { id: 'li-fol-fast', platform: 'LinkedIn', platformIcon: 'Linkedin', serviceType: 'Followers', tier: 'Fast', description: 'Fast company/page followers', pricePer1k: 1450, minOrder: 100, maxOrder: 20000, deliveryTime: '6-24 hours', refillGuarantee: true, features: ['Real-looking', 'Instant start', 'No password'] },
      { id: 'li-fol-plus', platform: 'LinkedIn', platformIcon: 'Linkedin', serviceType: 'Followers', tier: 'Plus', description: 'HQ followers', pricePer1k: 2030, minOrder: 100, maxOrder: 30000, deliveryTime: '12-48 hours', refillGuarantee: true, features: ['HQ profiles', 'Better retention', '30-day refill'] },
      { id: 'li-fol-pro', platform: 'LinkedIn', platformIcon: 'Linkedin', serviceType: 'Followers', tier: 'Pro', description: 'Pro followers', pricePer1k: 2610, minOrder: 200, maxOrder: 20000, deliveryTime: '1-3 days', refillGuarantee: true, features: ['Low drop', 'Active look', '60-day refill'] },
      { id: 'li-fol-steady', platform: 'LinkedIn', platformIcon: 'Linkedin', serviceType: 'Followers', tier: 'Steady', description: 'Steady followers', pricePer1k: 3190, minOrder: 500, maxOrder: 10000, deliveryTime: '2-5 days', refillGuarantee: true, features: ['Drip-feed', 'Organic look', '90-day refill'] },
      { id: 'li-fol-prem', platform: 'LinkedIn', platformIcon: 'Linkedin', serviceType: 'Followers', tier: 'Premium', description: 'Premium followers', pricePer1k: 4350, minOrder: 500, maxOrder: 5000, deliveryTime: '3-7 days', refillGuarantee: true, features: ['Near-zero drop', 'Aged accounts', 'Lifetime refill'] },
      { id: 'li-fol-elite', platform: 'LinkedIn', platformIcon: 'Linkedin', serviceType: 'Followers', tier: 'Elite', description: 'Elite followers', pricePer1k: 5800, minOrder: 1000, maxOrder: 3000, deliveryTime: '5-10 days', refillGuarantee: true, features: ['Elite quality', 'VIP support', 'Lifetime refill'] },

      { id: 'li-pos-fast', platform: 'LinkedIn', platformIcon: 'Linkedin', serviceType: 'Post Engagement', tier: 'Fast', description: 'Fast post likes + comments', pricePer1k: 1015, minOrder: 50, maxOrder: 20000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Instant start', 'All posts', 'No password'] },
      { id: 'li-pos-plus', platform: 'LinkedIn', platformIcon: 'Linkedin', serviceType: 'Post Engagement', tier: 'Plus', description: 'HQ engagement', pricePer1k: 1450, minOrder: 50, maxOrder: 30000, deliveryTime: '2-12 hours', refillGuarantee: true, features: ['HQ accounts', 'Better spread', '30-day refill'] },
      { id: 'li-pos-pro', platform: 'LinkedIn', platformIcon: 'Linkedin', serviceType: 'Post Engagement', tier: 'Pro', description: 'Pro engagement', pricePer1k: 1885, minOrder: 100, maxOrder: 20000, deliveryTime: '6-24 hours', refillGuarantee: true, features: ['Low drop', 'Active look', '60-day refill'] },
      { id: 'li-pos-steady', platform: 'LinkedIn', platformIcon: 'Linkedin', serviceType: 'Post Engagement', tier: 'Steady', description: 'Steady engagement', pricePer1k: 2320, minOrder: 200, maxOrder: 10000, deliveryTime: '12-48 hours', refillGuarantee: true, features: ['Drip-feed', 'Organic look', '90-day refill'] },
      { id: 'li-pos-prem', platform: 'LinkedIn', platformIcon: 'Linkedin', serviceType: 'Post Engagement', tier: 'Premium', description: 'Premium engagement', pricePer1k: 3190, minOrder: 200, maxOrder: 5000, deliveryTime: '1-3 days', refillGuarantee: true, features: ['Aged accounts', 'Near-zero drop', 'Lifetime refill'] },
      { id: 'li-pos-elite', platform: 'LinkedIn', platformIcon: 'Linkedin', serviceType: 'Post Engagement', tier: 'Elite', description: 'Elite engagement', pricePer1k: 4350, minOrder: 500, maxOrder: 3000, deliveryTime: '2-5 days', refillGuarantee: true, features: ['Elite quality', 'VIP support', 'Lifetime refill'] },
    ]
  },
  {
    name: 'SoundCloud',
    icon: 'Cloud',
    color: '#FF5500',
    services: [
      { id: 'sc-fol-fast', platform: 'SoundCloud', platformIcon: 'Cloud', serviceType: 'Followers', tier: 'Fast', description: 'Fast followers', pricePer1k: 580, minOrder: 100, maxOrder: 50000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Real-looking', 'Instant start', 'No password'] },
      { id: 'sc-fol-plus', platform: 'SoundCloud', platformIcon: 'Cloud', serviceType: 'Followers', tier: 'Plus', description: 'HQ followers', pricePer1k: 725, minOrder: 100, maxOrder: 100000, deliveryTime: '2-12 hours', refillGuarantee: true, features: ['HQ profiles', 'Better retention', '30-day refill'] },
      { id: 'sc-fol-pro', platform: 'SoundCloud', platformIcon: 'Cloud', serviceType: 'Followers', tier: 'Pro', description: 'Pro followers', pricePer1k: 1015, minOrder: 200, maxOrder: 50000, deliveryTime: '6-24 hours', refillGuarantee: true, features: ['Low drop', 'Active look', '60-day refill'] },
      { id: 'sc-fol-steady', platform: 'SoundCloud', platformIcon: 'Cloud', serviceType: 'Followers', tier: 'Steady', description: 'Steady followers', pricePer1k: 1300, minOrder: 500, maxOrder: 30000, deliveryTime: '1-3 days', refillGuarantee: true, features: ['Drip-feed', 'Organic look', '90-day refill'] },
      { id: 'sc-fol-prem', platform: 'SoundCloud', platformIcon: 'Cloud', serviceType: 'Followers', tier: 'Premium', description: 'Premium followers', pricePer1k: 1740, minOrder: 500, maxOrder: 20000, deliveryTime: '12-48 hours', refillGuarantee: true, features: ['Near-zero drop', 'Aged accounts', 'Lifetime refill'] },
      { id: 'sc-fol-elite', platform: 'SoundCloud', platformIcon: 'Cloud', serviceType: 'Followers', tier: 'Elite', description: 'Elite followers', pricePer1k: 2320, minOrder: 1000, maxOrder: 10000, deliveryTime: '24-72 hours', refillGuarantee: true, features: ['Elite quality', 'VIP support', 'Lifetime refill'] },

      { id: 'sc-pla-fast', platform: 'SoundCloud', platformIcon: 'Cloud', serviceType: 'Plays', tier: 'Fast', description: 'Fast track plays', pricePer1k: 290, minOrder: 1000, maxOrder: 1000000, deliveryTime: '1-6 hours', refillGuarantee: false, features: ['Instant start', 'All tracks', 'No password'] },
      { id: 'sc-pla-plus', platform: 'SoundCloud', platformIcon: 'Cloud', serviceType: 'Plays', tier: 'Plus', description: 'HQ plays', pricePer1k: 435, minOrder: 1000, maxOrder: 500000, deliveryTime: '2-12 hours', refillGuarantee: false, features: ['Better retention', 'Split available', 'Analytics safe'] },
      { id: 'sc-pla-pro', platform: 'SoundCloud', platformIcon: 'Cloud', serviceType: 'Plays', tier: 'Pro', description: 'Pro plays', pricePer1k: 580, minOrder: 2000, maxOrder: 300000, deliveryTime: '6-24 hours', refillGuarantee: false, features: ['High retention', 'Low drop', 'Safe delivery'] },
      { id: 'sc-pla-steady', platform: 'SoundCloud', platformIcon: 'Cloud', serviceType: 'Plays', tier: 'Steady', description: 'Steady plays', pricePer1k: 725, minOrder: 5000, maxOrder: 200000, deliveryTime: '1-3 days', refillGuarantee: false, features: ['Drip-feed', 'Organic pattern', 'Safe delivery'] },
      { id: 'sc-pla-prem', platform: 'SoundCloud', platformIcon: 'Cloud', serviceType: 'Plays', tier: 'Premium', description: 'Premium plays', pricePer1k: 1015, minOrder: 5000, maxOrder: 100000, deliveryTime: '12-48 hours', refillGuarantee: false, features: ['Max retention', 'Aged accounts', 'Best for charting'] },
      { id: 'sc-pla-elite', platform: 'SoundCloud', platformIcon: 'Cloud', serviceType: 'Plays', tier: 'Elite', description: 'Elite plays', pricePer1k: 1300, minOrder: 10000, maxOrder: 50000, deliveryTime: '24-72 hours', refillGuarantee: false, features: ['Elite quality', 'VIP delivery', 'Monetization safe'] },
    ]
  },
  {
    name: 'Twitch',
    icon: 'Radio',
    color: '#9146FF',
    services: [
      { id: 'tw-fol-fast', platform: 'Twitch', platformIcon: 'Radio', serviceType: 'Followers', tier: 'Fast', description: 'Fast Twitch followers', pricePer1k: 725, minOrder: 100, maxOrder: 50000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Real-looking', 'Instant start', 'No password'] },
      { id: 'tw-fol-plus', platform: 'Twitch', platformIcon: 'Radio', serviceType: 'Followers', tier: 'Plus', description: 'HQ followers', pricePer1k: 1015, minOrder: 100, maxOrder: 100000, deliveryTime: '2-12 hours', refillGuarantee: true, features: ['HQ profiles', 'Better retention', '30-day refill'] },
      { id: 'tw-fol-pro', platform: 'Twitch', platformIcon: 'Radio', serviceType: 'Followers', tier: 'Pro', description: 'Pro followers', pricePer1k: 1300, minOrder: 200, maxOrder: 50000, deliveryTime: '6-24 hours', refillGuarantee: true, features: ['Low drop', 'Active look', '60-day refill'] },
      { id: 'tw-fol-steady', platform: 'Twitch', platformIcon: 'Radio', serviceType: 'Followers', tier: 'Steady', description: 'Steady followers', pricePer1k: 1740, minOrder: 500, maxOrder: 30000, deliveryTime: '1-3 days', refillGuarantee: true, features: ['Drip-feed', 'Organic look', '90-day refill'] },
      { id: 'tw-fol-prem', platform: 'Twitch', platformIcon: 'Radio', serviceType: 'Followers', tier: 'Premium', description: 'Premium followers', pricePer1k: 2320, minOrder: 500, maxOrder: 20000, deliveryTime: '12-48 hours', refillGuarantee: true, features: ['Near-zero drop', 'Aged accounts', 'Lifetime refill'] },
      { id: 'tw-fol-elite', platform: 'Twitch', platformIcon: 'Radio', serviceType: 'Followers', tier: 'Elite', description: 'Elite followers', pricePer1k: 2900, minOrder: 1000, maxOrder: 10000, deliveryTime: '24-72 hours', refillGuarantee: true, features: ['Elite quality', 'VIP support', 'Lifetime refill'] },

      { id: 'tw-vie-fast', platform: 'Twitch', platformIcon: 'Radio', serviceType: 'Live Views', tier: 'Fast', description: 'Fast live stream viewers', pricePer1k: 1450, minOrder: 50, maxOrder: 10000, deliveryTime: 'Instant-30 min', refillGuarantee: false, features: ['Instant start', 'Live streams', 'No password'] },
      { id: 'tw-vie-plus', platform: 'Twitch', platformIcon: 'Radio', serviceType: 'Live Views', tier: 'Plus', description: 'HQ live viewers', pricePer1k: 2030, minOrder: 50, maxOrder: 20000, deliveryTime: '5-60 min', refillGuarantee: false, features: ['Better retention', 'Chat ready', 'Analytics safe'] },
      { id: 'tw-vie-pro', platform: 'Twitch', platformIcon: 'Radio', serviceType: 'Live Views', tier: 'Pro', description: 'Pro live viewers', pricePer1k: 2610, minOrder: 100, maxOrder: 10000, deliveryTime: '10 min - 2 hours', refillGuarantee: false, features: ['High retention', 'Low drop', 'Safe delivery'] },
      { id: 'tw-vie-steady', platform: 'Twitch', platformIcon: 'Radio', serviceType: 'Live Views', tier: 'Steady', description: 'Steady live viewers', pricePer1k: 3190, minOrder: 200, maxOrder: 5000, deliveryTime: '1-6 hours', refillGuarantee: false, features: ['Drip-feed', 'Organic pattern', 'Safe delivery'] },
      { id: 'tw-vie-prem', platform: 'Twitch', platformIcon: 'Radio', serviceType: 'Live Views', tier: 'Premium', description: 'Premium live viewers', pricePer1k: 4350, minOrder: 200, maxOrder: 3000, deliveryTime: '30 min - 6 hours', refillGuarantee: false, features: ['Max retention', 'Aged accounts', 'Affiliate safe'] },
      { id: 'tw-vie-elite', platform: 'Twitch', platformIcon: 'Radio', serviceType: 'Live Views', tier: 'Elite', description: 'Elite live viewers', pricePer1k: 5800, minOrder: 500, maxOrder: 2000, deliveryTime: '1-12 hours', refillGuarantee: false, features: ['Elite quality', 'VIP delivery', 'Partner safe'] },
    ]
  },
  {
    name: 'Pinterest',
    icon: 'Pin',
    color: '#BD081C',
    services: [
      { id: 'pi-fol-fast', platform: 'Pinterest', platformIcon: 'Pin', serviceType: 'Followers', tier: 'Fast', description: 'Fast Pinterest followers', pricePer1k: 580, minOrder: 100, maxOrder: 50000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Real-looking', 'Instant start', 'No password'] },
      { id: 'pi-fol-plus', platform: 'Pinterest', platformIcon: 'Pin', serviceType: 'Followers', tier: 'Plus', description: 'HQ followers', pricePer1k: 725, minOrder: 100, maxOrder: 100000, deliveryTime: '2-12 hours', refillGuarantee: true, features: ['HQ profiles', 'Better retention', '30-day refill'] },
      { id: 'pi-fol-pro', platform: 'Pinterest', platformIcon: 'Pin', serviceType: 'Followers', tier: 'Pro', description: 'Pro followers', pricePer1k: 1015, minOrder: 200, maxOrder: 50000, deliveryTime: '6-24 hours', refillGuarantee: true, features: ['Low drop', 'Active look', '60-day refill'] },
      { id: 'pi-fol-steady', platform: 'Pinterest', platformIcon: 'Pin', serviceType: 'Followers', tier: 'Steady', description: 'Steady followers', pricePer1k: 1300, minOrder: 500, maxOrder: 30000, deliveryTime: '1-3 days', refillGuarantee: true, features: ['Drip-feed', 'Organic look', '90-day refill'] },
      { id: 'pi-fol-prem', platform: 'Pinterest', platformIcon: 'Pin', serviceType: 'Followers', tier: 'Premium', description: 'Premium followers', pricePer1k: 1740, minOrder: 500, maxOrder: 20000, deliveryTime: '12-48 hours', refillGuarantee: true, features: ['Near-zero drop', 'Aged accounts', 'Lifetime refill'] },
      { id: 'pi-fol-elite', platform: 'Pinterest', platformIcon: 'Pin', serviceType: 'Followers', tier: 'Elite', description: 'Elite followers', pricePer1k: 2320, minOrder: 1000, maxOrder: 10000, deliveryTime: '24-72 hours', refillGuarantee: true, features: ['Elite quality', 'VIP support', 'Lifetime refill'] },

      { id: 'pi-sav-fast', platform: 'Pinterest', platformIcon: 'Pin', serviceType: 'Saves', tier: 'Fast', description: 'Fast pin saves', pricePer1k: 435, minOrder: 50, maxOrder: 100000, deliveryTime: 'Instant-2 hours', refillGuarantee: true, features: ['Instant start', 'All pins', 'No password'] },
      { id: 'pi-sav-plus', platform: 'Pinterest', platformIcon: 'Pin', serviceType: 'Saves', tier: 'Plus', description: 'HQ saves', pricePer1k: 580, minOrder: 50, maxOrder: 200000, deliveryTime: '30 min - 4 hours', refillGuarantee: true, features: ['HQ accounts', 'Better retention', '30-day refill'] },
      { id: 'pi-sav-pro', platform: 'Pinterest', platformIcon: 'Pin', serviceType: 'Saves', tier: 'Pro', description: 'Pro saves', pricePer1k: 725, minOrder: 100, maxOrder: 100000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Low drop', 'Active look', '60-day refill'] },
      { id: 'pi-sav-steady', platform: 'Pinterest', platformIcon: 'Pin', serviceType: 'Saves', tier: 'Steady', description: 'Steady saves', pricePer1k: 1015, minOrder: 200, maxOrder: 50000, deliveryTime: '3-12 hours', refillGuarantee: true, features: ['Drip-feed', 'Organic look', '90-day refill'] },
      { id: 'pi-sav-prem', platform: 'Pinterest', platformIcon: 'Pin', serviceType: 'Saves', tier: 'Premium', description: 'Premium saves', pricePer1k: 1300, minOrder: 200, maxOrder: 30000, deliveryTime: '6-24 hours', refillGuarantee: true, features: ['Aged accounts', 'Near-zero drop', 'Lifetime refill'] },
      { id: 'pi-sav-elite', platform: 'Pinterest', platformIcon: 'Pin', serviceType: 'Saves', tier: 'Elite', description: 'Elite saves', pricePer1k: 1740, minOrder: 500, maxOrder: 15000, deliveryTime: '12-48 hours', refillGuarantee: true, features: ['Elite quality', 'VIP support', 'Lifetime refill'] },
    ]
  },
  {
    name: 'Threads',
    icon: 'AtSign',
    color: '#000000',
    services: [
      { id: 'th-fol-fast', platform: 'Threads', platformIcon: 'AtSign', serviceType: 'Followers', tier: 'Fast', description: 'Fast Threads followers', pricePer1k: 510, minOrder: 100, maxOrder: 50000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Real-looking', 'Instant start', 'No password'] },
      { id: 'th-fol-plus', platform: 'Threads', platformIcon: 'AtSign', serviceType: 'Followers', tier: 'Plus', description: 'HQ followers', pricePer1k: 725, minOrder: 100, maxOrder: 100000, deliveryTime: '2-12 hours', refillGuarantee: true, features: ['HQ profiles', 'Better retention', '30-day refill'] },
      { id: 'th-fol-pro', platform: 'Threads', platformIcon: 'AtSign', serviceType: 'Followers', tier: 'Pro', description: 'Pro followers', pricePer1k: 1015, minOrder: 200, maxOrder: 50000, deliveryTime: '6-24 hours', refillGuarantee: true, features: ['Low drop', 'Active look', '60-day refill'] },
      { id: 'th-fol-steady', platform: 'Threads', platformIcon: 'AtSign', serviceType: 'Followers', tier: 'Steady', description: 'Steady followers', pricePer1k: 1300, minOrder: 500, maxOrder: 30000, deliveryTime: '1-3 days', refillGuarantee: true, features: ['Drip-feed', 'Organic look', '90-day refill'] },
      { id: 'th-fol-prem', platform: 'Threads', platformIcon: 'AtSign', serviceType: 'Followers', tier: 'Premium', description: 'Premium followers', pricePer1k: 1740, minOrder: 500, maxOrder: 20000, deliveryTime: '12-48 hours', refillGuarantee: true, features: ['Near-zero drop', 'Aged accounts', 'Lifetime refill'] },
      { id: 'th-fol-elite', platform: 'Threads', platformIcon: 'AtSign', serviceType: 'Followers', tier: 'Elite', description: 'Elite followers', pricePer1k: 2320, minOrder: 1000, maxOrder: 10000, deliveryTime: '24-72 hours', refillGuarantee: true, features: ['Elite quality', 'VIP support', 'Lifetime refill'] },

      { id: 'th-lik-fast', platform: 'Threads', platformIcon: 'AtSign', serviceType: 'Likes', tier: 'Fast', description: 'Fast thread likes', pricePer1k: 290, minOrder: 50, maxOrder: 100000, deliveryTime: 'Instant-1 hour', refillGuarantee: true, features: ['Instant start', 'All threads', 'No password'] },
      { id: 'th-lik-plus', platform: 'Threads', platformIcon: 'AtSign', serviceType: 'Likes', tier: 'Plus', description: 'HQ likes', pricePer1k: 435, minOrder: 50, maxOrder: 200000, deliveryTime: '5-30 min', refillGuarantee: true, features: ['HQ accounts', 'Split available', '30-day refill'] },
      { id: 'th-lik-pro', platform: 'Threads', platformIcon: 'AtSign', serviceType: 'Likes', tier: 'Pro', description: 'Pro likes', pricePer1k: 580, minOrder: 100, maxOrder: 100000, deliveryTime: '10-60 min', refillGuarantee: true, features: ['Better spread', 'Low drop', '60-day refill'] },
      { id: 'th-lik-steady', platform: 'Threads', platformIcon: 'AtSign', serviceType: 'Likes', tier: 'Steady', description: 'Steady likes', pricePer1k: 725, minOrder: 200, maxOrder: 50000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Drip-feed', 'Organic look', '90-day refill'] },
      { id: 'th-lik-prem', platform: 'Threads', platformIcon: 'AtSign', serviceType: 'Likes', tier: 'Premium', description: 'Premium likes', pricePer1k: 1015, minOrder: 200, maxOrder: 30000, deliveryTime: '30 min - 3 hours', refillGuarantee: true, features: ['Aged accounts', 'Near-zero drop', 'Lifetime refill'] },
      { id: 'th-lik-elite', platform: 'Threads', platformIcon: 'AtSign', serviceType: 'Likes', tier: 'Elite', description: 'Elite likes', pricePer1k: 1450, minOrder: 500, maxOrder: 15000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Elite accounts', 'VIP support', 'Lifetime refill'] },
    ]
  },
  {
    name: 'Snapchat',
    icon: 'Ghost',
    color: '#FFFC00',
    services: [
      { id: 'sn-fol-fast', platform: 'Snapchat', platformIcon: 'Ghost', serviceType: 'Followers', tier: 'Fast', description: 'Fast Snapchat followers', pricePer1k: 580, minOrder: 100, maxOrder: 50000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Real-looking', 'Instant start', 'No password'] },
      { id: 'sn-fol-plus', platform: 'Snapchat', platformIcon: 'Ghost', serviceType: 'Followers', tier: 'Plus', description: 'HQ followers', pricePer1k: 870, minOrder: 100, maxOrder: 100000, deliveryTime: '2-12 hours', refillGuarantee: true, features: ['HQ profiles', 'Better retention', '30-day refill'] },
      { id: 'sn-fol-pro', platform: 'Snapchat', platformIcon: 'Ghost', serviceType: 'Followers', tier: 'Pro', description: 'Pro followers', pricePer1k: 1160, minOrder: 200, maxOrder: 50000, deliveryTime: '6-24 hours', refillGuarantee: true, features: ['Low drop', 'Active look', '60-day refill'] },
      { id: 'sn-fol-steady', platform: 'Snapchat', platformIcon: 'Ghost', serviceType: 'Followers', tier: 'Steady', description: 'Steady followers', pricePer1k: 1450, minOrder: 500, maxOrder: 30000, deliveryTime: '1-3 days', refillGuarantee: true, features: ['Drip-feed', 'Organic look', '90-day refill'] },
      { id: 'sn-fol-prem', platform: 'Snapchat', platformIcon: 'Ghost', serviceType: 'Followers', tier: 'Premium', description: 'Premium followers', pricePer1k: 2030, minOrder: 500, maxOrder: 20000, deliveryTime: '12-48 hours', refillGuarantee: true, features: ['Near-zero drop', 'Aged accounts', 'Lifetime refill'] },
      { id: 'sn-fol-elite', platform: 'Snapchat', platformIcon: 'Ghost', serviceType: 'Followers', tier: 'Elite', description: 'Elite followers', pricePer1k: 2610, minOrder: 1000, maxOrder: 10000, deliveryTime: '24-72 hours', refillGuarantee: true, features: ['Elite quality', 'VIP support', 'Lifetime refill'] },

      { id: 'sn-vie-fast', platform: 'Snapchat', platformIcon: 'Ghost', serviceType: 'Story Views', tier: 'Fast', description: 'Fast story views', pricePer1k: 218, minOrder: 100, maxOrder: 100000, deliveryTime: 'Instant-1 hour', refillGuarantee: false, features: ['Instant start', 'All stories', 'No password'] },
      { id: 'sn-vie-plus', platform: 'Snapchat', platformIcon: 'Ghost', serviceType: 'Story Views', tier: 'Plus', description: 'HQ story views', pricePer1k: 290, minOrder: 100, maxOrder: 200000, deliveryTime: '5-30 min', refillGuarantee: false, features: ['Better retention', 'Split available', 'Analytics safe'] },
      { id: 'sn-vie-pro', platform: 'Snapchat', platformIcon: 'Ghost', serviceType: 'Story Views', tier: 'Pro', description: 'Pro story views', pricePer1k: 435, minOrder: 500, maxOrder: 100000, deliveryTime: '10-60 min', refillGuarantee: false, features: ['High retention', 'Low drop', 'Safe delivery'] },
      { id: 'sn-vie-steady', platform: 'Snapchat', platformIcon: 'Ghost', serviceType: 'Story Views', tier: 'Steady', description: 'Steady views', pricePer1k: 580, minOrder: 1000, maxOrder: 50000, deliveryTime: '1-6 hours', refillGuarantee: false, features: ['Drip-feed', 'Organic pattern', 'Safe delivery'] },
      { id: 'sn-vie-prem', platform: 'Snapchat', platformIcon: 'Ghost', serviceType: 'Story Views', tier: 'Premium', description: 'Premium views', pricePer1k: 725, minOrder: 1000, maxOrder: 30000, deliveryTime: '30 min - 3 hours', refillGuarantee: false, features: ['Max retention', 'Aged accounts', 'Best for spotlight'] },
      { id: 'sn-vie-elite', platform: 'Snapchat', platformIcon: 'Ghost', serviceType: 'Story Views', tier: 'Elite', description: 'Elite views', pricePer1k: 1015, minOrder: 2000, maxOrder: 15000, deliveryTime: '1-6 hours', refillGuarantee: false, features: ['Elite quality', 'VIP delivery', 'Monetization safe'] },
    ]
  },
  {
    name: 'Google Reviews',
    icon: 'Star',
    color: '#4285F4',
    services: [
      { id: 'gr-rev-fast', platform: 'Google Reviews', platformIcon: 'Star', serviceType: 'Reviews', tier: 'Fast', description: 'Fast Google reviews', pricePer1k: 14500, minOrder: 1, maxOrder: 500, deliveryTime: '6-24 hours', refillGuarantee: true, features: ['4-5 star', 'Instant start', 'No password'] },
      { id: 'gr-rev-plus', platform: 'Google Reviews', platformIcon: 'Star', serviceType: 'Reviews', tier: 'Plus', description: 'HQ custom reviews', pricePer1k: 21750, minOrder: 1, maxOrder: 1000, deliveryTime: '12-48 hours', refillGuarantee: true, features: ['Custom text', 'Local guides', '30-day refill'] },
      { id: 'gr-rev-pro', platform: 'Google Reviews', platformIcon: 'Star', serviceType: 'Reviews', tier: 'Pro', description: 'Pro reviews with photos', pricePer1k: 29000, minOrder: 1, maxOrder: 500, deliveryTime: '1-3 days', refillGuarantee: true, features: ['With photos', 'Local guides', '60-day refill'] },
      { id: 'gr-rev-steady', platform: 'Google Reviews', platformIcon: 'Star', serviceType: 'Reviews', tier: 'Steady', description: 'Steady review drip', pricePer1k: 36250, minOrder: 5, maxOrder: 300, deliveryTime: '2-5 days', refillGuarantee: true, features: ['Drip-feed', 'Custom text', '90-day refill'] },
      { id: 'gr-rev-prem', platform: 'Google Reviews', platformIcon: 'Star', serviceType: 'Reviews', tier: 'Premium', description: 'Premium reviews', pricePer1k: 43500, minOrder: 5, maxOrder: 200, deliveryTime: '3-7 days', refillGuarantee: true, features: ['Aged accounts', 'Near-zero drop', 'Lifetime refill'] },
      { id: 'gr-rev-elite', platform: 'Google Reviews', platformIcon: 'Star', serviceType: 'Reviews', tier: 'Elite', description: 'Elite reviews', pricePer1k: 58000, minOrder: 10, maxOrder: 100, deliveryTime: '5-10 days', refillGuarantee: true, features: ['Elite quality', 'VIP support', 'Lifetime refill'] },
    ]
  },
  {
    name: 'WhatsApp',
    icon: 'MessageCircle',
    color: '#25D366',
    services: [
      { id: 'wa-mem-fast', platform: 'WhatsApp', platformIcon: 'MessageCircle', serviceType: 'Channel Members', tier: 'Fast', description: 'Fast channel members', pricePer1k: 870, minOrder: 100, maxOrder: 50000, deliveryTime: '1-6 hours', refillGuarantee: true, features: ['Real-looking', 'Instant start', 'No password'] },
      { id: 'wa-mem-plus', platform: 'WhatsApp', platformIcon: 'MessageCircle', serviceType: 'Channel Members', tier: 'Plus', description: 'HQ members', pricePer1k: 1160, minOrder: 100, maxOrder: 100000, deliveryTime: '2-12 hours', refillGuarantee: true, features: ['HQ profiles', 'Better retention', '30-day refill'] },
      { id: 'wa-mem-pro', platform: 'WhatsApp', platformIcon: 'MessageCircle', serviceType: 'Channel Members', tier: 'Pro', description: 'Pro members', pricePer1k: 1450, minOrder: 200, maxOrder: 50000, deliveryTime: '6-24 hours', refillGuarantee: true, features: ['Low drop', 'Active look', '60-day refill'] },
      { id: 'wa-mem-steady', platform: 'WhatsApp', platformIcon: 'MessageCircle', serviceType: 'Channel Members', tier: 'Steady', description: 'Steady members', pricePer1k: 1885, minOrder: 500, maxOrder: 30000, deliveryTime: '1-3 days', refillGuarantee: true, features: ['Drip-feed', 'Organic look', '90-day refill'] },
      { id: 'wa-mem-prem', platform: 'WhatsApp', platformIcon: 'MessageCircle', serviceType: 'Channel Members', tier: 'Premium', description: 'Premium members', pricePer1k: 2465, minOrder: 500, maxOrder: 20000, deliveryTime: '12-48 hours', refillGuarantee: true, features: ['Near-zero drop', 'Aged accounts', 'Lifetime refill'] },
      { id: 'wa-mem-elite', platform: 'WhatsApp', platformIcon: 'MessageCircle', serviceType: 'Channel Members', tier: 'Elite', description: 'Elite members', pricePer1k: 3190, minOrder: 1000, maxOrder: 10000, deliveryTime: '24-72 hours', refillGuarantee: true, features: ['Elite quality', 'VIP support', 'Lifetime refill'] },

      { id: 'wa-vie-fast', platform: 'WhatsApp', platformIcon: 'MessageCircle', serviceType: 'Status Views', tier: 'Fast', description: 'Fast status views', pricePer1k: 218, minOrder: 100, maxOrder: 100000, deliveryTime: 'Instant-1 hour', refillGuarantee: false, features: ['Instant start', 'All statuses', 'No password'] },
      { id: 'wa-vie-plus', platform: 'WhatsApp', platformIcon: 'MessageCircle', serviceType: 'Status Views', tier: 'Plus', description: 'HQ status views', pricePer1k: 290, minOrder: 100, maxOrder: 200000, deliveryTime: '5-30 min', refillGuarantee: false, features: ['Better retention', 'Split available', 'Analytics safe'] },
      { id: 'wa-vie-pro', platform: 'WhatsApp', platformIcon: 'MessageCircle', serviceType: 'Status Views', tier: 'Pro', description: 'Pro status views', pricePer1k: 435, minOrder: 500, maxOrder: 100000, deliveryTime: '10-60 min', refillGuarantee: false, features: ['High retention', 'Low drop', 'Safe delivery'] },
      { id: 'wa-vie-steady', platform: 'WhatsApp', platformIcon: 'MessageCircle', serviceType: 'Status Views', tier: 'Steady', description: 'Steady views', pricePer1k: 580, minOrder: 1000, maxOrder: 50000, deliveryTime: '1-6 hours', refillGuarantee: false, features: ['Drip-feed', 'Organic pattern', 'Safe delivery'] },
      { id: 'wa-vie-prem', platform: 'WhatsApp', platformIcon: 'MessageCircle', serviceType: 'Status Views', tier: 'Premium', description: 'Premium views', pricePer1k: 725, minOrder: 1000, maxOrder: 30000, deliveryTime: '30 min - 3 hours', refillGuarantee: false, features: ['Max retention', 'Aged accounts', 'Best for reach'] },
      { id: 'wa-vie-elite', platform: 'WhatsApp', platformIcon: 'MessageCircle', serviceType: 'Status Views', tier: 'Elite', description: 'Elite views', pricePer1k: 1015, minOrder: 2000, maxOrder: 15000, deliveryTime: '1-6 hours', refillGuarantee: false, features: ['Elite quality', 'VIP delivery', 'Monetization safe'] },
    ]
  },
];

export const allServices = platforms.flatMap(p => p.services);
export const totalServices = allServices.length;

export function getServicesByPlatform(platformName: string) {
  return platforms.find(p => p.name === platformName)?.services || [];
}

export function getServicesByTier(tier: Tier) {
  return allServices.filter(s => s.tier === tier);
}

export function getPlatforms() {
  return platforms.map(p => ({ name: p.name, icon: p.icon, color: p.color }));
}
